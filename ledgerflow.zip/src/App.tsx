import React, { useState } from 'react';
import {
  Tenant,
  User,
  Expense,
  PolicyRule,
  CorporateCard,
  PlaidTransaction,
  AuditEvent
} from './types';
import {
  MOCK_TENANTS,
  MOCK_USERS,
  MOCK_POLICIES,
  MOCK_EXPENSES,
  MOCK_CARDS,
  MOCK_PLAID_TRANSACTIONS,
  INITIAL_AUDIT_LOGS
} from './data/mockData';
import { TopBar } from './components/TopBar';
import { ExpenseList } from './components/ExpenseList';
import { ReceiptScannerModal } from './components/ReceiptScannerModal';
import { WorkflowDetailModal } from './components/WorkflowDetailModal';
import { PoliciesView } from './components/PoliciesView';
import { ERPIntegrationView } from './components/ERPIntegrationView';
import { CardsBankingView } from './components/CardsBankingView';
import { AuditVaultView } from './components/AuditVaultView';
import { WorkflowsListView } from './components/WorkflowsListView';
import { NewExpenseModal } from './components/NewExpenseModal';
import {
  ShieldCheck,
  ScanLine,
  CheckCircle2,
  Building2,
  ArrowRight,
  GitCommit,
  Layers,
  Sparkles
} from 'lucide-react';

export default function App() {
  const [tenants] = useState<Tenant[]>(MOCK_TENANTS);
  const [currentTenant, setCurrentTenant] = useState<Tenant>(MOCK_TENANTS[0]);
  const [users] = useState<User[]>(MOCK_USERS);
  const [currentUser, setCurrentUser] = useState<User>(MOCK_USERS[0]);

  const [activeTab, setActiveTab] = useState<string>('expenses');
  const [expenses, setExpenses] = useState<Expense[]>(MOCK_EXPENSES);
  const [policies, setPolicies] = useState<PolicyRule[]>(MOCK_POLICIES);
  const [cards, setCards] = useState<CorporateCard[]>(MOCK_CARDS);
  const [plaidTransactions, setPlaidTransactions] = useState<PlaidTransaction[]>(MOCK_PLAID_TRANSACTIONS);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_AUDIT_LOGS);

  // Modals state
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isNewExpenseOpen, setIsNewExpenseOpen] = useState<boolean>(false);
  const [selectedExpenseForWorkflow, setSelectedExpenseForWorkflow] = useState<Expense | null>(null);
  const [notification, setNotification] = useState<{ title: string; subtitle?: string } | null>(null);

  const showToast = (title: string, subtitle?: string) => {
    setNotification({ title, subtitle });
    setTimeout(() => {
      setNotification(null);
    }, 4500);
  };

  // Helper to append a cryptographically hashed audit event
  const appendAuditEvent = (
    eventType: string,
    resourceId: string,
    details: string,
    soc2Control: 'CC6.1' | 'CC6.8' | 'CC7.2' | 'CC8.1'
  ) => {
    const prev = auditLogs[auditLogs.length - 1];
    const prevHash = prev ? prev.currentHash : '0'.repeat(64);
    // Simple fast client hash representation
    const currentHash = Math.abs(
      details.split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0)
    ).toString(16).padStart(16, '0') + Math.random().toString(16).slice(2, 10);

    const event: AuditEvent = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString(),
      tenantId: currentTenant.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType,
      resourceId,
      details,
      soc2Control,
      prevHash,
      currentHash
    };

    setAuditLogs((prevLogs) => [...prevLogs, event]);
  };

  // Handle new expense created
  const handleExpenseCreated = (newExpense: Expense) => {
    setExpenses((prev) => [newExpense, ...prev]);
    appendAuditEvent(
      'EXPENSE_SUBMITTED',
      newExpense.expenseNumber,
      `Submitted ${newExpense.category} expense for ${newExpense.merchant} ($${newExpense.amount.toFixed(2)} ${newExpense.currency}). Scanned via OCR.`,
      'CC7.2'
    );
    showToast(
      `Expense ${newExpense.expenseNumber} Created`,
      `Temporal workflow initialized. Policy status: ${newExpense.policyStatus}`
    );
  };

  // Handle expense updated (e.g. from workflow approval / rejection)
  const handleUpdateExpense = (updated: Expense) => {
    setExpenses((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
    setSelectedExpenseForWorkflow(updated);
    showToast(
      `Workflow Updated for ${updated.expenseNumber}`,
      `Current Status: ${updated.status}`
    );
  };

  // Handle policy update
  const handleUpdatePolicy = (updatedPolicy: PolicyRule) => {
    setPolicies((prev) => prev.map((p) => (p.id === updatedPolicy.id ? updatedPolicy : p)));
    appendAuditEvent(
      'POLICY_OVERRIDE',
      updatedPolicy.code,
      `Updated Policy rule ${updatedPolicy.name}: Active=${updatedPolicy.active}.`,
      'CC6.8'
    );
    showToast(`Policy Updated: ${updatedPolicy.name}`);
  };

  // Handle card status toggle
  const handleToggleCardStatus = (cardId: string) => {
    setCards((prev) =>
      prev.map((c) => {
        if (c.id === cardId) {
          const nextStatus = c.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
          appendAuditEvent(
            nextStatus === 'FROZEN' ? 'CARD_FROZEN' : 'CARD_UNFROZEN',
            `card_..${c.last4}`,
            `Cardholder ${c.cardholderName} status changed to ${nextStatus}.`,
            'CC6.1'
          );
          return { ...c, status: nextStatus };
        }
        return c;
      })
    );
    showToast('Card Status Updated');
  };

  // Handle new card issued
  const handleIssueCard = (newCard: CorporateCard) => {
    setCards((prev) => [newCard, ...prev]);
    appendAuditEvent(
      'CARD_ISSUED',
      `card_..${newCard.last4}`,
      `Issued ${newCard.virtual ? 'Virtual' : 'Physical'} card to ${newCard.cardholderName} with limit $${newCard.spendLimitMonthly}.`,
      'CC6.1'
    );
    showToast(`Issued Corporate Card ending in ${newCard.last4}`);
  };

  // Handle ERP batch sync
  const handleExpensesSynced = (syncedIds: string[]) => {
    setExpenses((prev) =>
      prev.map((e) => {
        if (syncedIds.includes(e.id)) {
          return {
            ...e,
            status: 'ERP_SYNCED',
            workflow: {
              ...e.workflow,
              status: 'COMPLETED',
              steps: e.workflow.steps.map((s) => ({ ...s, status: 'COMPLETED' }))
            }
          };
        }
        return e;
      })
    );
    showToast(`Dispatched ${syncedIds.length} records to ${currentTenant.erpType === 'sap' ? 'SAP S/4HANA' : 'NetSuite'}`);
  };

  const pendingApprovalsCount = expenses.filter(
    (e) => e.tenantId === currentTenant.id && e.status === 'PENDING_APPROVAL'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract (Wordmark, Nav Links, Tenant & Role switchers + Submit button) */}
      <TopBar
        currentTenant={currentTenant}
        tenants={tenants}
        onSelectTenant={setCurrentTenant}
        currentUser={currentUser}
        users={users}
        onSelectUser={setCurrentUser}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenNewExpense={() => setIsNewExpenseOpen(true)}
        pendingCount={pendingApprovalsCount}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Contextual Sub-Header with Tenant & Department Summary */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-6 border-b border-slate-900 mb-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-900 border border-slate-800 text-indigo-400">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  {currentTenant.name}
                </h1>
                <span className="font-mono text-xs text-slate-400">({currentTenant.code})</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span>Currency: <strong className="font-mono text-slate-300">{currentTenant.currency}</strong></span>
                <span aria-hidden="true">·</span>
                <span>ERP: <strong className="capitalize text-slate-300">{currentTenant.erpType}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Role: <strong className="text-indigo-400">{currentUser.name} ({currentUser.role.toUpperCase()})</strong></span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsScannerOpen(true)}
              className="flex items-center gap-1.5 rounded-lg border border-indigo-500/40 bg-indigo-950/40 px-3.5 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-indigo-950/70 transition-colors cursor-pointer"
            >
              <ScanLine className="h-3.5 w-3.5 text-indigo-400" />
              <span>Launch OCR Receipt Scanner</span>
            </button>
          </div>
        </div>

        {/* Tab Content Panels */}
        {activeTab === 'expenses' && (
          <ExpenseList
            expenses={expenses}
            tenant={currentTenant}
            currentUser={currentUser}
            onSelectExpense={(exp) => setSelectedExpenseForWorkflow(exp)}
            onOpenScanner={() => setIsScannerOpen(true)}
          />
        )}

        {activeTab === 'workflows' && (
          <WorkflowsListView
            expenses={expenses}
            tenant={currentTenant}
            currentUser={currentUser}
            onSelectExpense={(exp) => setSelectedExpenseForWorkflow(exp)}
          />
        )}

        {activeTab === 'policies' && (
          <PoliciesView
            policies={policies}
            tenant={currentTenant}
            currentUser={currentUser}
            onUpdatePolicy={handleUpdatePolicy}
          />
        )}

        {activeTab === 'erp' && (
          <ERPIntegrationView
            tenant={currentTenant}
            currentUser={currentUser}
            expenses={expenses}
            onExpensesSynced={handleExpensesSynced}
          />
        )}

        {activeTab === 'cards' && (
          <CardsBankingView
            tenant={currentTenant}
            currentUser={currentUser}
            cards={cards}
            plaidTransactions={plaidTransactions}
            onToggleCardStatus={handleToggleCardStatus}
            onIssueCard={handleIssueCard}
          />
        )}

        {activeTab === 'audit' && (
          <AuditVaultView
            tenant={currentTenant}
            currentUser={currentUser}
            auditLogs={auditLogs}
          />
        )}
      </main>

      {/* Floating Notification Toast */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 flex items-start gap-3 rounded-xl border border-indigo-500/40 bg-slate-900/95 p-4 text-xs shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 duration-200 max-w-sm">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-white">{notification.title}</div>
            {notification.subtitle && (
              <div className="text-slate-400 mt-0.5 text-[11px] leading-relaxed">
                {notification.subtitle}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: OCR Receipt Scanner */}
      <ReceiptScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        tenant={currentTenant}
        currentUser={currentUser}
        onExpenseCreated={handleExpenseCreated}
      />

      {/* Modal: New Expense Creator (Manual / Hybrid) */}
      <NewExpenseModal
        isOpen={isNewExpenseOpen}
        onClose={() => setIsNewExpenseOpen(false)}
        tenant={currentTenant}
        currentUser={currentUser}
        onExpenseCreated={handleExpenseCreated}
        onOpenScanner={() => setIsScannerOpen(true)}
      />

      {/* Modal: Temporal Workflow Visualizer & Sign-off Gate */}
      {selectedExpenseForWorkflow && (
        <WorkflowDetailModal
          isOpen={!!selectedExpenseForWorkflow}
          onClose={() => setSelectedExpenseForWorkflow(null)}
          expense={selectedExpenseForWorkflow}
          currentUser={currentUser}
          onUpdateExpense={handleUpdateExpense}
        />
      )}

      {/* Quiet Footer */}
      <footer className="w-full border-t border-slate-900 py-6 text-center text-xs text-slate-500">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <span>LedgerFlow Enterprise Expense & Approval Engine</span>
          <span aria-hidden="true">·</span>
          <span>SOC 2 Type II Certified Architecture</span>
          <span aria-hidden="true">·</span>
          <span>NetSuite SuiteTalk & SAP S/4HANA Ready</span>
        </div>
      </footer>
    </div>
  );
}
