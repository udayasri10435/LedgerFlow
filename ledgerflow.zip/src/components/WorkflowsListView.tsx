import React, { useState } from 'react';
import { Expense, Tenant, User } from '../types';
import {
  GitCommit,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  ChevronRight,
  Search,
  Filter,
  Layers,
  ArrowRight,
  ShieldCheck,
  Server
} from 'lucide-react';

interface WorkflowsListViewProps {
  expenses: Expense[];
  tenant: Tenant;
  currentUser: User;
  onSelectExpense: (expense: Expense) => void;
}

export const WorkflowsListView: React.FC<WorkflowsListViewProps> = ({
  expenses,
  tenant,
  currentUser,
  onSelectExpense,
}) => {
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'WAITING_APPROVAL' | 'RUNNING' | 'COMPLETED' | 'FAILED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const tenantExpenses = expenses.filter((e) => e.tenantId === tenant.id);

  const filtered = tenantExpenses.filter((e) => {
    if (statusFilter !== 'ALL' && e.workflow.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        e.expenseNumber.toLowerCase().includes(q) ||
        e.workflow.workflowId.toLowerCase().includes(q) ||
        e.submitterName.toLowerCase().includes(q) ||
        e.merchant.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white">Temporal Workflow Orchestration Engine</h2>
            <span className="font-mono text-xs text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
              TaskQueue: finance-approvals-queue
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Durable execution state machines enforcing multi-gate approval chains, automated timeouts, and compensating rollbacks.
          </p>
        </div>

        {/* Filter segment */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          {[
            { id: 'ALL', label: 'All Workflows' },
            { id: 'WAITING_APPROVAL', label: 'Waiting Gate' },
            { id: 'RUNNING', label: 'In Progress' },
            { id: 'COMPLETED', label: 'Completed' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setStatusFilter(f.id as any)}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                statusFilter === f.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Workflow Instances List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-500 text-xs">
            No active Temporal workflows matching selected filter criteria.
          </div>
        ) : (
          filtered.map((exp) => {
            const currentStep = exp.workflow.steps.find((s) => s.status === 'ACTIVE');
            const completedCount = exp.workflow.steps.filter((s) => s.status === 'COMPLETED').length;
            const progress = Math.round((completedCount / exp.workflow.steps.length) * 100);

            return (
              <div
                key={exp.id}
                onClick={() => onSelectExpense(exp)}
                className="group rounded-xl border border-slate-800 bg-slate-900/50 p-4 transition-all hover:border-slate-700 hover:bg-slate-900/80 cursor-pointer space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400 shrink-0">
                      <GitCommit className="h-4 w-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-white">
                          {exp.workflow.workflowId}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="font-semibold text-xs text-slate-300">
                          {exp.expenseNumber} ({exp.merchant})
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Submitter: <span className="text-slate-200">{exp.submitterName}</span> · Amount: <span className="font-mono font-semibold text-emerald-400">${exp.amount.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-xs font-mono px-2 py-0.5 rounded border ${
                        exp.workflow.status === 'COMPLETED'
                          ? 'border-emerald-500/30 bg-emerald-950/30 text-emerald-400'
                          : exp.workflow.status === 'WAITING_APPROVAL'
                          ? 'border-amber-500/30 bg-amber-950/30 text-amber-400'
                          : 'border-slate-700 bg-slate-800 text-slate-300'
                      }`}
                    >
                      {exp.workflow.status}
                    </span>
                    <ChevronRight className="h-4 w-4 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                  </div>
                </div>

                {/* Progress Pipeline bar */}
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>
                      Current Step: {currentStep ? `${currentStep.title} (${currentStep.assignedToName})` : 'All Gates Cleared'}
                    </span>
                    <span className="tabular-nums">{progress}% Executed</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        exp.workflow.status === 'COMPLETED' ? 'bg-emerald-500' : 'bg-indigo-500'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
