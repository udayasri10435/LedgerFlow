import React, { useState, useEffect } from 'react';
import { AuditEvent, Tenant, User } from '../types';
import {
  ShieldCheck,
  Lock,
  FileCheck,
  Download,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Search,
  KeyRound,
  FileSpreadsheet,
  Link,
  Shield,
  Loader2
} from 'lucide-react';

interface AuditVaultViewProps {
  tenant: Tenant;
  currentUser: User;
  auditLogs: AuditEvent[];
}

export const AuditVaultView: React.FC<AuditVaultViewProps> = ({
  tenant,
  currentUser,
  auditLogs,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean;
    totalBlocks: number;
    latestHash: string;
    verifiedAt: string;
  } | null>(null);

  // Filter logs for this tenant or global
  const filteredLogs = auditLogs.filter((log) => {
    if (log.tenantId !== tenant.id) return false;
    if (filterType !== 'ALL' && log.eventType !== filterType) return false;
    return true;
  });

  const handleVerifyChain = async () => {
    setIsVerifying(true);
    try {
      const res = await fetch('/api/audit/verify');
      const data = await res.json();
      if (data.success) {
        setVerificationResult({
          valid: data.valid,
          totalBlocks: data.totalBlocks,
          latestHash: data.latestHash,
          verifiedAt: data.verifiedAt
        });
      }
    } catch (err) {
      console.error(err);
      // Fallback verification in client
      let valid = true;
      for (let i = 1; i < auditLogs.length; i++) {
        if (auditLogs[i].prevHash !== auditLogs[i - 1].currentHash) {
          valid = false;
          break;
        }
      }
      setVerificationResult({
        valid,
        totalBlocks: auditLogs.length,
        latestHash: auditLogs[auditLogs.length - 1]?.currentHash || 'hash',
        verifiedAt: new Date().toISOString()
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const exportAuditorBundle = () => {
    const bundle = {
      complianceStandard: "AICPA SOC 2 Type II Trust Services Criteria",
      tenantId: tenant.id,
      tenantName: tenant.name,
      exportTimestamp: new Date().toISOString(),
      auditorAttestation: {
        actor: currentUser.name,
        role: currentUser.role,
        verifiedIntegrity: verificationResult?.valid ?? true,
        hashRoot: verificationResult?.latestHash ?? auditLogs[auditLogs.length - 1]?.currentHash
      },
      trustCriteriaMappings: [
        { control: "CC6.1", name: "Logical Access Controls", status: "ENFORCED" },
        { control: "CC6.8", name: "Policy Configuration & Change Management", status: "ENFORCED" },
        { control: "CC7.2", name: "Transaction Processing Integrity", status: "ENFORCED" },
        { control: "CC8.1", name: "Segregation of Duties", status: "ENFORCED" }
      ],
      cryptographicAuditChain: filteredLogs
    };

    const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `soc2_audit_vault_${tenant.code}_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white">SOC 2 Type II Immutable Audit Vault</h2>
            <span className="font-mono text-xs text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
              SHA-256 Hash Chained
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Tamper-evident cryptographic ledger recording every expense approval, policy override, OCR scan, and ERP dispatch.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleVerifyChain}
            disabled={isVerifying}
            className="flex items-center gap-1.5 rounded-lg border border-indigo-500/40 bg-indigo-950/40 px-3.5 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-indigo-950/70 transition-colors cursor-pointer"
          >
            {isVerifying ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <ShieldCheck className="h-3.5 w-3.5 text-indigo-400" />
            )}
            <span>Verify Chain Integrity</span>
          </button>

          <button
            onClick={exportAuditorBundle}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow hover:bg-indigo-500 transition-colors cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Auditor Export Package</span>
          </button>
        </div>
      </div>

      {/* Verification Status Banner if executed */}
      {verificationResult && (
        <div
          className={`rounded-xl border p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
            verificationResult.valid
              ? 'border-emerald-500/30 bg-emerald-950/20 text-emerald-300'
              : 'border-rose-500/30 bg-rose-950/20 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
            <div>
              <div className="text-xs font-bold text-white">
                Cryptographic Audit Chain: 100% Valid & Tamper-Evident
              </div>
              <div className="text-[11px] text-slate-300 font-mono mt-0.5">
                Verified {verificationResult.totalBlocks} sequential hash blocks · Root Hash: {verificationResult.latestHash.slice(0, 24)}...
              </div>
            </div>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-1 rounded">
            AICPA Trust Criteria Passed
          </span>
        </div>
      )}

      {/* SOC 2 Trust Criteria Controls Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        {[
          {
            code: "CC6.1",
            title: "Access Control & RBAC",
            desc: "Submitters separated from Approvers. Granular multi-tenant isolation.",
            status: "Compliant"
          },
          {
            code: "CC6.8",
            title: "Policy & Change Log",
            desc: "All threshold updates & executive overrides digitally signed.",
            status: "Compliant"
          },
          {
            code: "CC7.2",
            title: "Transaction Integrity",
            desc: "Idempotent Temporal workflows with compensating transaction rollbacks.",
            status: "Compliant"
          },
          {
            code: "CC8.1",
            title: "Segregation of Duties",
            desc: "Engine blocks employees from approving their own expense reports.",
            status: "Compliant"
          }
        ].map((ctrl) => (
          <div key={ctrl.code} className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-semibold text-indigo-400">{ctrl.code}</span>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" /> {ctrl.status}
              </span>
            </div>
            <h4 className="text-xs font-semibold text-white">{ctrl.title}</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">{ctrl.desc}</p>
          </div>
        ))}
      </div>

      {/* Audit Log Table with Hash Chaining */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden">
        {/* Table controls */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-300">
            <span className="font-semibold text-white">Immutable Event Ledger</span>
            <span className="text-slate-500 ml-2">({filteredLogs.length} verified events)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-mono">Filter Event:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Event Types</option>
              <option value="APPROVAL_GRANTED">APPROVAL_GRANTED</option>
              <option value="EXPENSE_SUBMITTED">EXPENSE_SUBMITTED</option>
              <option value="POLICY_OVERRIDE">POLICY_OVERRIDE</option>
              <option value="ERP_DISPATCHED">ERP_DISPATCHED</option>
            </select>
          </div>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800 font-mono">
            <tr>
              <th className="py-3 px-4 font-semibold">Timestamp (UTC)</th>
              <th className="py-3 px-4 font-semibold">Actor & Role</th>
              <th className="py-3 px-4 font-semibold">Event Type & Control</th>
              <th className="py-3 px-4 font-semibold">Details & Attestation</th>
              <th className="py-3 px-4 font-semibold text-right">Cryptographic SHA-256 Link</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {filteredLogs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-800/40">
                <td className="py-3 px-4 text-slate-400 tabular-nums">
                  {new Date(log.timestamp).toISOString().replace('T', ' ').slice(0, 19)}
                </td>
                <td className="py-3 px-4">
                  <div className="font-sans font-semibold text-slate-200">{log.actorName}</div>
                  <div className="text-[10px] text-slate-500 uppercase">{log.actorRole}</div>
                </td>
                <td className="py-3 px-4">
                  <div className="text-indigo-400 font-semibold">{log.eventType}</div>
                  <span className="text-[10px] text-emerald-400">SOC 2 {log.soc2Control}</span>
                </td>
                <td className="py-3 px-4 font-sans text-slate-300 max-w-sm">
                  {log.details}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="text-[10px] text-slate-400 hover:text-white transition-colors cursor-help" title={`Full Hash: ${log.currentHash}\nPrev: ${log.prevHash}`}>
                    <span className="text-slate-600 mr-1">curr:</span>
                    <span className="text-indigo-300">{log.currentHash.slice(0, 12)}...</span>
                  </div>
                  <div className="text-[9px] text-slate-600">
                    prev: {log.prevHash.slice(0, 8)}...
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
