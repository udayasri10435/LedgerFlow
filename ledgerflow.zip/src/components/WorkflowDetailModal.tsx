import React, { useState } from 'react';
import { Expense, User, WorkflowStep } from '../types';
import {
  GitCommit,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  Shield,
  ArrowRight,
  RotateCcw,
  Send,
  MessageSquare,
  FileCheck,
  X,
  Layers,
  Terminal,
  Server
} from 'lucide-react';

interface WorkflowDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  expense: Expense;
  currentUser: User;
  onUpdateExpense: (updated: Expense) => void;
}

export const WorkflowDetailModal: React.FC<WorkflowDetailModalProps> = ({
  isOpen,
  onClose,
  expense,
  currentUser,
  onUpdateExpense,
}) => {
  const [approvalNote, setApprovalNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'graph' | 'history' | 'receipt'>('graph');

  if (!isOpen) return null;

  const { workflow } = expense;

  const handleAction = async (action: 'APPROVE' | 'REJECT' | 'OVERRIDE' | 'COMPENSATE') => {
    setIsSubmitting(true);
    try {
      // Dispatch to Temporal backend simulation
      await fetch('/api/temporal/signal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workflowId: workflow.workflowId,
          action,
          actorName: currentUser.name,
          actorRole: currentUser.role,
          notes: approvalNote || (action === 'APPROVE' ? 'Approved in accordance with policy' : 'Policy action taken'),
          tenantId: expense.tenantId
        })
      });

      // Update local workflow state
      const updatedSteps = [...workflow.steps];
      let newExpenseStatus = expense.status;
      let newWorkflowStatus = workflow.status;

      if (action === 'APPROVE' || action === 'OVERRIDE') {
        const activeIdx = updatedSteps.findIndex((s) => s.status === 'ACTIVE');
        if (activeIdx !== -1) {
          updatedSteps[activeIdx].status = 'COMPLETED';
          updatedSteps[activeIdx].completedAt = new Date().toISOString();
          updatedSteps[activeIdx].assignedToName = currentUser.name;
          updatedSteps[activeIdx].note = approvalNote || 'Digital signature verified.';

          // Advance to next step or complete
          if (activeIdx + 1 < updatedSteps.length) {
            updatedSteps[activeIdx + 1].status = 'ACTIVE';
            if (activeIdx + 1 === updatedSteps.length - 1) {
              // Last step is ERP post
              newExpenseStatus = 'APPROVED';
            }
          } else {
            newExpenseStatus = 'ERP_SYNCED';
            newWorkflowStatus = 'COMPLETED';
          }
        }
      } else if (action === 'REJECT') {
        const activeIdx = updatedSteps.findIndex((s) => s.status === 'ACTIVE');
        if (activeIdx !== -1) {
          updatedSteps[activeIdx].status = 'REJECTED';
          updatedSteps[activeIdx].completedAt = new Date().toISOString();
          updatedSteps[activeIdx].note = approvalNote || 'Rejected due to policy non-compliance.';
        }
        newExpenseStatus = 'REJECTED';
        newWorkflowStatus = 'FAILED';
      } else if (action === 'COMPENSATE') {
        // Rollback compensating transaction
        updatedSteps.forEach((s) => {
          if (s.status === 'COMPLETED') s.status = 'PENDING';
        });
        if (updatedSteps[0]) updatedSteps[0].status = 'ACTIVE';
        newExpenseStatus = 'PENDING_APPROVAL';
        newWorkflowStatus = 'COMPENSATED';
      }

      const updatedExpense: Expense = {
        ...expense,
        status: newExpenseStatus,
        workflow: {
          ...workflow,
          status: newWorkflowStatus,
          steps: updatedSteps,
          historyEvents: [
            ...workflow.historyEvents,
            {
              eventId: workflow.historyEvents.length + 1,
              eventType: `TemporalSignal[${action}]`,
              timestamp: new Date().toISOString(),
              details: `Executed by ${currentUser.name} (${currentUser.role}). Note: ${approvalNote || 'N/A'}`,
              status: action === 'REJECT' ? 'ERROR' : 'SUCCESS'
            }
          ]
        }
      };

      onUpdateExpense(updatedExpense);
      setApprovalNote('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentStep = workflow.steps.find((s) => s.status === 'ACTIVE');
  const canUserApprove =
    currentStep &&
    (currentUser.role === 'controller' || currentUser.role === currentStep.roleRequired);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative flex max-h-[92vh] w-full max-w-5xl flex-col rounded-xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400">
              <GitCommit className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-white">
                  Temporal Workflow State Machine
                </h2>
                <span className="font-mono text-xs text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
                  {workflow.workflowId}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                <span>TaskQueue: {workflow.taskQueue}</span>
                <span aria-hidden="true">·</span>
                <span>RunID: {workflow.runId}</span>
                <span aria-hidden="true">·</span>
                <span
                  className={
                    workflow.status === 'COMPLETED'
                      ? 'text-emerald-400'
                      : workflow.status === 'WAITING_APPROVAL' || workflow.status === 'RUNNING'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }
                >
                  Status: {workflow.status}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex rounded-md bg-slate-900 p-0.5 border border-slate-800 text-xs">
              <button
                onClick={() => setActiveTab('graph')}
                className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                  activeTab === 'graph' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Workflow Graph
              </button>
              <button
                onClick={() => setActiveTab('history')}
                className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                  activeTab === 'history' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Event History ({workflow.historyEvents.length})
              </button>
              <button
                onClick={() => setActiveTab('receipt')}
                className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                  activeTab === 'receipt' ? 'bg-indigo-600 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Itemized Receipt
              </button>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer ml-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(92vh-140px)] space-y-6">
          {/* Quick Expense Header Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 rounded-lg bg-slate-950/70 p-3.5 border border-slate-800 text-xs font-mono">
            <div>
              <div className="text-[11px] font-sans text-slate-500 uppercase">Expense Number</div>
              <div className="text-white font-semibold mt-0.5">{expense.expenseNumber}</div>
            </div>
            <div>
              <div className="text-[11px] font-sans text-slate-500 uppercase">Merchant & Date</div>
              <div className="text-slate-200 mt-0.5 truncate">{expense.merchant} · {expense.date}</div>
            </div>
            <div>
              <div className="text-[11px] font-sans text-slate-500 uppercase">Amount</div>
              <div className="text-emerald-400 font-semibold tabular-nums mt-0.5">
                ${expense.amount.toFixed(2)} {expense.currency}
              </div>
            </div>
            <div>
              <div className="text-[11px] font-sans text-slate-500 uppercase">Cost Center / GL</div>
              <div className="text-slate-300 mt-0.5">{expense.costCenter} · {expense.glAccount.split('-')[0]}</div>
            </div>
            <div>
              <div className="text-[11px] font-sans text-slate-500 uppercase">Policy Evaluation</div>
              <div className="mt-0.5">
                {expense.policyStatus === 'COMPLIANT' ? (
                  <span className="text-emerald-400">Compliant</span>
                ) : (
                  <span className="text-amber-400">Flagged Exceptions ({expense.policyFlags.length})</span>
                )}
              </div>
            </div>
          </div>

          {activeTab === 'graph' && (
            <div className="space-y-6">
              {/* Visual Pipeline Nodes */}
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                  Sequential Approval & Orchestration Pipeline
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 relative">
                  {workflow.steps.map((step, idx) => {
                    const isCompleted = step.status === 'COMPLETED';
                    const isActive = step.status === 'ACTIVE';
                    const isRejected = step.status === 'REJECTED';

                    return (
                      <div
                        key={step.id}
                        className={`relative rounded-xl border p-4 transition-all flex flex-col justify-between ${
                          isActive
                            ? 'border-indigo-500 bg-indigo-950/20 shadow-lg shadow-indigo-950/40 ring-1 ring-indigo-500/50'
                            : isCompleted
                            ? 'border-emerald-500/30 bg-emerald-950/10'
                            : isRejected
                            ? 'border-rose-500/40 bg-rose-950/20'
                            : 'border-slate-800 bg-slate-950/40 text-slate-500'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-mono text-[11px] text-slate-400">
                              0{step.stepNumber}
                            </span>
                            {isCompleted && (
                              <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400">
                                <CheckCircle2 className="h-3.5 w-3.5" />
                                Done
                              </span>
                            )}
                            {isActive && (
                              <span className="flex items-center gap-1 text-[11px] font-mono text-indigo-400 animate-pulse">
                                <Clock className="h-3.5 w-3.5" />
                                Active Gate
                              </span>
                            )}
                            {isRejected && (
                              <span className="flex items-center gap-1 text-[11px] font-mono text-rose-400">
                                <XCircle className="h-3.5 w-3.5" />
                                Blocked
                              </span>
                            )}
                            {step.status === 'PENDING' && (
                              <span className="text-[11px] font-mono text-slate-500">
                                Queued
                              </span>
                            )}
                          </div>

                          <h4 className="text-xs font-semibold text-slate-100">
                            {step.title}
                          </h4>
                          <p className="text-[11px] text-slate-400 mt-1">
                            Assigned: <span className="text-slate-200">{step.assignedToName}</span>
                          </p>
                        </div>

                        {step.note && (
                          <div className="mt-3 rounded bg-slate-900/80 p-2 text-[11px] text-slate-300 border border-slate-800">
                            <span className="text-slate-500 block text-[10px] uppercase font-mono">Log Note</span>
                            {step.note}
                          </div>
                        )}

                        {step.completedAt && (
                          <div className="mt-2 text-[10px] font-mono text-slate-500">
                            {new Date(step.completedAt).toLocaleTimeString()} · {new Date(step.completedAt).toLocaleDateString()}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Action Decision Control Box */}
              {canUserApprove && workflow.status !== 'COMPLETED' && workflow.status !== 'FAILED' && (
                <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/20 p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                        <FileCheck className="h-4 w-4 text-indigo-400" />
                        Action Required: Step {currentStep?.stepNumber} ({currentStep?.title})
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Logged in as <span className="font-semibold text-slate-200">{currentUser.name}</span> ({currentUser.role.toUpperCase()})
                      </p>
                    </div>
                    {expense.policyFlags.length > 0 && (
                      <span className="text-xs font-mono text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded border border-amber-400/20">
                        Warning: Policy Exception Present
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-300">
                      Approval / Sign-off Comments (Stamped on SOC 2 Audit Ledger)
                    </label>
                    <textarea
                      rows={2}
                      value={approvalNote}
                      onChange={(e) => setApprovalNote(e.target.value)}
                      placeholder="Add audit sign-off rationale or compliance notes..."
                      className="mt-1.5 w-full rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-xs text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
                    <button
                      onClick={() => handleAction('REJECT')}
                      disabled={isSubmitting}
                      className="flex items-center gap-1.5 rounded-lg border border-rose-800/40 bg-rose-950/20 px-3 py-1.5 text-xs font-semibold text-rose-300 hover:bg-rose-950/40 transition-colors cursor-pointer"
                    >
                      <XCircle className="h-3.5 w-3.5" />
                      <span>Reject & Halt Workflow</span>
                    </button>

                    {expense.policyFlags.length > 0 && (currentUser.role === 'controller' || currentUser.role === 'manager') && (
                      <button
                        onClick={() => handleAction('OVERRIDE')}
                        disabled={isSubmitting}
                        className="flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-950/30 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-950/60 transition-colors cursor-pointer"
                      >
                        <Shield className="h-3.5 w-3.5" />
                        <span>Executive Policy Override</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleAction('APPROVE')}
                      disabled={isSubmitting}
                      className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-4 py-1.5 text-xs font-semibold text-white shadow hover:bg-emerald-500 transition-colors cursor-pointer"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Approve with Digital Signature</span>
                    </button>
                  </div>
                </div>
              )}

              {/* SAGA Compensation simulation */}
              {currentUser.role === 'controller' && workflow.status === 'COMPLETED' && (
                <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-3 text-xs">
                  <div className="text-slate-400">
                    <span className="font-semibold text-slate-200">Temporal SAGA Compensation:</span> Workflow completed. If fraudulent transaction is discovered, you can execute compensating rollback.
                  </div>
                  <button
                    onClick={() => handleAction('COMPENSATE')}
                    className="flex items-center gap-1.5 text-xs font-mono text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Trigger SAGA Rollback</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Durable Event Stream (Temporal Event Log)
                </h4>
                <span className="text-xs font-mono text-slate-500">
                  Deterministic Replay Available
                </span>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden divide-y divide-slate-800 font-mono text-xs">
                {workflow.historyEvents.map((evt) => (
                  <div key={evt.eventId} className="p-3 flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <span className="text-slate-600 font-bold shrink-0">#{evt.eventId}</span>
                      <div>
                        <div className="font-semibold text-slate-200">{evt.eventType}</div>
                        <div className="text-slate-400 font-sans text-xs mt-0.5">{evt.details}</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                          evt.status === 'SUCCESS'
                            ? 'text-emerald-400 bg-emerald-950/40'
                            : evt.status === 'WARNING'
                            ? 'text-amber-400 bg-amber-950/40'
                            : 'text-rose-400 bg-rose-950/40'
                        }`}
                      >
                        {evt.status}
                      </span>
                      <div className="text-[10px] text-slate-600 mt-1">
                        {new Date(evt.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'receipt' && expense.receipt && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Receipt metadata */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Receipt Summary & Security Signature
                </h4>
                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-slate-400">Merchant</span>
                    <span className="text-white font-semibold">{expense.receipt.merchant}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-slate-400">Address</span>
                    <span className="text-slate-300">{expense.receipt.address || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-slate-400">Date & Time</span>
                    <span className="text-slate-300">{expense.receipt.date} {expense.receipt.time || ''}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-slate-400">Subtotal / Tax</span>
                    <span className="text-slate-300">${expense.receipt.subtotal.toFixed(2)} / ${expense.receipt.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800 pb-1.5">
                    <span className="text-slate-400">Total</span>
                    <span className="text-emerald-400 font-bold">${expense.receipt.total.toFixed(2)}</span>
                  </div>
                  <div className="pt-2">
                    <span className="text-slate-500 block text-[10px]">SHA-256 Receipt Signature</span>
                    <span className="text-[11px] text-indigo-400 break-all">{expense.receipt.sha256Hash}</span>
                  </div>
                </div>
              </div>

              {/* Line items table */}
              <div className="rounded-xl border border-slate-800 bg-slate-950 p-4">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                  Extracted Itemized Line Items
                </h4>
                <div className="divide-y divide-slate-800 text-xs font-mono">
                  {expense.receipt.lineItems.map((li) => (
                    <div key={li.id} className="py-2 flex justify-between items-center">
                      <div>
                        <div className="text-slate-200 font-sans">{li.name}</div>
                        <div className="text-[10px] text-slate-500">Qty: {li.qty} · Unit: ${li.unitPrice.toFixed(2)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-semibold">${li.total.toFixed(2)}</div>
                        {li.category === 'Alcohol' && (
                          <span className="text-[9px] text-amber-400 bg-amber-400/10 px-1 py-0.5 rounded">
                            GL 6200
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
