import React, { useState } from 'react';
import { CorporateCard, PlaidTransaction, Tenant, User } from '../types';
import {
  CreditCard,
  Building,
  Lock,
  Unlock,
  Plus,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  DollarSign,
  Layers,
  Sparkles
} from 'lucide-react';

interface CardsBankingViewProps {
  tenant: Tenant;
  currentUser: User;
  cards: CorporateCard[];
  plaidTransactions: PlaidTransaction[];
  onToggleCardStatus: (cardId: string) => void;
  onIssueCard: (newCard: CorporateCard) => void;
}

export const CardsBankingView: React.FC<CardsBankingViewProps> = ({
  tenant,
  currentUser,
  cards,
  plaidTransactions,
  onToggleCardStatus,
  onIssueCard,
}) => {
  const [activeTab, setActiveTab] = useState<'cards' | 'plaid'>('cards');
  const [isIssueModalOpen, setIsIssueModalOpen] = useState<boolean>(false);

  // New card form state
  const [newCardholder, setNewCardholder] = useState<string>('Alex Chen');
  const [newCardLimit, setNewCardLimit] = useState<number>(5000);
  const [newCardType, setNewCardType] = useState<'virtual' | 'physical'>('virtual');
  const [newCardDept, setNewCardDept] = useState<string>(tenant.departments[0] || 'Engineering');

  const tenantCards = cards.filter((c) => c.tenantId === tenant.id);
  const tenantTransactions = plaidTransactions.filter((t) => t.tenantId === tenant.id);

  const handleCreateCard = (e: React.FormEvent) => {
    e.preventDefault();
    const last4 = Math.floor(1000 + Math.random() * 9000).toString();
    const created: CorporateCard = {
      id: `crd_${Date.now()}`,
      tenantId: tenant.id,
      cardholderName: newCardholder,
      cardholderEmail: `${newCardholder.toLowerCase().replace(' ', '.')}@${tenant.code.toLowerCase()}.corp`,
      last4,
      brand: 'Visa',
      expMonth: 10,
      expYear: 2029,
      status: 'ACTIVE',
      spendLimitMonthly: newCardLimit,
      spentThisMonth: 0,
      virtual: newCardType === 'virtual',
      department: newCardDept,
      autoFreezeOnPolicyBreach: true
    };
    onIssueCard(created);
    setIsIssueModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white">Stripe Corporate Cards & Plaid Bank Sync</h2>
            <span className="font-mono text-xs text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
              Live Feed
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time transaction streaming, automated receipt reconciliation, and policy-driven card freeze controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('cards')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                activeTab === 'cards' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Stripe Corporate Cards ({tenantCards.length})
            </button>
            <button
              onClick={() => setActiveTab('plaid')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                activeTab === 'plaid' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Plaid Bank Feeds ({tenantTransactions.length})
            </button>
          </div>

          {activeTab === 'cards' && (currentUser.role === 'controller' || currentUser.role === 'manager') && (
            <button
              onClick={() => setIsIssueModalOpen(true)}
              className="flex items-center gap-1.5 rounded-md bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-emerald-500 transition-colors cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Issue Card</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {tenantCards.map((card) => {
            const usagePercent = Math.min(100, Math.round((card.spentThisMonth / card.spendLimitMonthly) * 100));
            const isFrozen = card.status === 'FROZEN';

            return (
              <div
                key={card.id}
                className={`relative rounded-xl border p-5 transition-all flex flex-col justify-between ${
                  isFrozen
                    ? 'border-rose-900/60 bg-rose-950/15'
                    : 'border-slate-800 bg-slate-900/50 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-mono text-xs font-semibold text-slate-400">
                      {card.virtual ? 'Virtual Corporate Card' : 'Physical Commercial Card'}
                    </span>
                    <button
                      onClick={() => onToggleCardStatus(card.id)}
                      className={`flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded cursor-pointer transition-colors ${
                        isFrozen
                          ? 'bg-rose-900/40 text-rose-300 hover:bg-rose-900/70 border border-rose-700/50'
                          : 'bg-emerald-950/40 text-emerald-400 hover:bg-emerald-950/80 border border-emerald-800/40'
                      }`}
                    >
                      {isFrozen ? (
                        <>
                          <Lock className="h-3 w-3" />
                          <span>FROZEN</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="h-3 w-3" />
                          <span>ACTIVE</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Card Visual styling */}
                  <div className="rounded-lg bg-gradient-to-br from-slate-800 to-slate-950 p-4 border border-slate-700/60 font-mono shadow-inner mb-4">
                    <div className="flex justify-between items-start text-xs text-slate-400">
                      <span>{card.brand.toUpperCase()}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300">
                        {tenant.code}
                      </span>
                    </div>
                    <div className="my-3 text-base tracking-widest text-white font-semibold">
                      •••• •••• •••• {card.last4}
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span className="uppercase">{card.cardholderName}</span>
                      <span>EXP {card.expMonth}/{card.expYear.toString().slice(-2)}</span>
                    </div>
                  </div>

                  {/* Spend usage progress */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400 font-mono">
                      <span>Monthly Spend</span>
                      <span className="text-white font-semibold tabular-nums">
                        ${card.spentThisMonth.toFixed(2)} / ${card.spendLimitMonthly.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          usagePercent > 80 ? 'bg-rose-500' : usagePercent > 50 ? 'bg-amber-400' : 'bg-indigo-500'
                        }`}
                        style={{ width: `${usagePercent}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Dept: {card.department}</span>
                  {card.autoFreezeOnPolicyBreach && (
                    <span className="text-indigo-400 flex items-center gap-1 font-mono">
                      <ShieldCheck className="h-3 w-3" /> Auto-Freeze On Breach
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Plaid Bank Transactions Table */
        <div className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden">
          <div className="p-4 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white">Live Plaid Corporate Bank Feed</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Automatically reconciled with employee receipts and OCR expense reports.
              </p>
            </div>
            <span className="font-mono text-xs text-emerald-400 flex items-center gap-1.5">
              <RefreshCw className="h-3.5 w-3.5" />
              Synced 2m ago
            </span>
          </div>

          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold">Bank Description / Merchant</th>
                <th className="py-3 px-4 font-semibold">Corporate Account</th>
                <th className="py-3 px-4 font-semibold text-right">Amount ({tenant.currency})</th>
                <th className="py-3 px-4 font-semibold">Reconciliation Status</th>
                <th className="py-3 px-4 font-semibold">Matched Report</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
              {tenantTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-800/40">
                  <td className="py-3 px-4 text-slate-300 tabular-nums">{tx.date}</td>
                  <td className="py-3 px-4 font-sans font-medium text-white">{tx.merchant}</td>
                  <td className="py-3 px-4 text-slate-400 text-[11px]">{tx.accountName}</td>
                  <td className="py-3 px-4 text-right text-emerald-400 font-semibold tabular-nums">
                    ${tx.amount.toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    {tx.status === 'MATCHED' ? (
                      <span className="flex items-center gap-1 text-emerald-400 text-xs font-sans">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Matched with Receipt
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-amber-400 text-xs font-sans">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        Missing Receipt
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {tx.matchedExpenseNumber ? (
                      <span className="text-indigo-400 font-semibold">{tx.matchedExpenseNumber}</span>
                    ) : (
                      <button className="text-[11px] font-sans text-indigo-400 hover:underline cursor-pointer">
                        Request Upload from Employee
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Issue Card Modal */}
      {isIssueModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-semibold text-white">Issue Stripe Corporate Card</h3>
            <form onSubmit={handleCreateCard} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-medium">Cardholder Name</label>
                <input
                  type="text"
                  required
                  value={newCardholder}
                  onChange={(e) => setNewCardholder(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Monthly Spending Limit ($ USD)</label>
                <input
                  type="number"
                  required
                  value={newCardLimit}
                  onChange={(e) => setNewCardLimit(parseFloat(e.target.value) || 0)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono tabular-nums focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Card Format</label>
                <select
                  value={newCardType}
                  onChange={(e) => setNewCardType(e.target.value as any)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer"
                >
                  <option value="virtual">Virtual Card (Instant issuance for SaaS & Cloud)</option>
                  <option value="physical">Physical Card (Corporate Travel & Dining)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-medium">Department Assignment</label>
                <select
                  value={newCardDept}
                  onChange={(e) => setNewCardDept(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer"
                >
                  {tenant.departments.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsIssueModalOpen(false)}
                  className="rounded-md border border-slate-800 px-3 py-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-md bg-indigo-600 px-4 py-1.5 font-semibold text-white hover:bg-indigo-500 transition-colors cursor-pointer"
                >
                  Issue Corporate Card
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
