import React, { useState, useMemo } from 'react';
import { Expense, Tenant, User } from '../types';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowUpDown,
  FileText,
  ExternalLink,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  SendHorizontal
} from 'lucide-react';

interface ExpenseListProps {
  expenses: Expense[];
  tenant: Tenant;
  currentUser: User;
  onSelectExpense: (expense: Expense) => void;
  onOpenScanner: () => void;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({
  expenses,
  tenant,
  currentUser,
  onSelectExpense,
  onOpenScanner,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date' | 'amount'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Filter expenses scoped to current tenant
  const tenantExpenses = useMemo(() => {
    return expenses.filter((e) => e.tenantId === tenant.id);
  }, [expenses, tenant.id]);

  const filteredExpenses = useMemo(() => {
    return tenantExpenses
      .filter((exp) => {
        // Status filter
        if (statusFilter === 'pending' && exp.status !== 'PENDING_APPROVAL') return false;
        if (statusFilter === 'flagged' && exp.policyStatus !== 'FLAGGED') return false;
        if (statusFilter === 'approved' && exp.status !== 'APPROVED' && exp.status !== 'ERP_SYNCED') return false;
        if (statusFilter === 'synced' && exp.status !== 'ERP_SYNCED') return false;

        // Department filter
        if (departmentFilter !== 'all' && exp.department !== departmentFilter) return false;

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchNumber = exp.expenseNumber.toLowerCase().includes(q);
          const matchMerchant = exp.merchant.toLowerCase().includes(q);
          const matchSubmitter = exp.submitterName.toLowerCase().includes(q);
          const matchCategory = exp.category.toLowerCase().includes(q);
          if (!matchNumber && !matchMerchant && !matchSubmitter && !matchCategory) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'amount') {
          return sortOrder === 'desc' ? b.amount - a.amount : a.amount - b.amount;
        }
        return sortOrder === 'desc'
          ? new Date(b.date).getTime() - new Date(a.date).getTime()
          : new Date(a.date).getTime() - new Date(b.date).getTime();
      });
  }, [tenantExpenses, statusFilter, departmentFilter, searchQuery, sortBy, sortOrder]);

  const toggleSort = (field: 'date' | 'amount') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  // Metrics summary
  const totalSpend = useMemo(() => {
    return tenantExpenses.reduce((acc, curr) => acc + curr.amount, 0);
  }, [tenantExpenses]);

  const pendingApprovalsCount = useMemo(() => {
    return tenantExpenses.filter((e) => e.status === 'PENDING_APPROVAL').length;
  }, [tenantExpenses]);

  const flaggedCount = useMemo(() => {
    return tenantExpenses.filter((e) => e.policyStatus === 'FLAGGED').length;
  }, [tenantExpenses]);

  return (
    <div className="space-y-6">
      {/* Metrics Row (Claim-to-Proof Adjacency, Tabular Numbers, Zero Pill) */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs font-medium text-slate-400">Total Filtered Spend</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-white">
            ${totalSpend.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {tenant.currency}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
            <span>{tenantExpenses.length} total corporate reports</span>
            <span aria-hidden="true">·</span>
            <span>FY2026</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs font-medium text-slate-400">Awaiting Workflow Sign-off</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-amber-400">
            {pendingApprovalsCount}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
            <span>Temporal durable timers active</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-400 font-mono">48h SLA</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <div className="text-xs font-medium text-slate-400">Policy Exception Flags</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-rose-400">
            {flaggedCount}
          </div>
          <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
            <span>Per-meal or alcohol flags</span>
            <span aria-hidden="true">·</span>
            <span>Audited</span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs font-medium text-slate-400">Connected Enterprise ERP</div>
            <div className="mt-1 text-lg font-bold text-white flex items-center gap-2">
              <span className="capitalize">{tenant.erpType === 'sap' ? 'SAP S/4HANA' : 'NetSuite SuiteTalk'}</span>
              <span className="h-2 w-2 rounded-full bg-emerald-400"></span>
            </div>
          </div>
          <div className="text-xs text-slate-500 flex items-center gap-1.5 mt-2">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span>Two-way GL Ledger Sync</span>
          </div>
        </div>
      </div>

      {/* Control Bar: Filters, Search & View Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
        {/* Interactive Segmented Filter Controls */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800 overflow-x-auto">
          {[
            { id: 'all', label: 'All Expenses' },
            { id: 'pending', label: 'Pending Review' },
            { id: 'flagged', label: 'Policy Flags' },
            { id: 'approved', label: 'Approved' },
            { id: 'synced', label: 'ERP Synced' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                statusFilter === tab.id
                  ? 'bg-slate-800 text-white shadow-xs font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search & Department Scope */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search merchant, ID, submitter..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-md border border-slate-800 bg-slate-900 py-1.5 pl-8 pr-3 text-xs text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="rounded-md border border-slate-800 bg-slate-900 py-1.5 px-2.5 text-xs text-slate-300 focus:border-indigo-500 focus:outline-none cursor-pointer"
          >
            <option value="all">All Departments</option>
            {tenant.departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* High-Density Data Grid (Compliant with 36px-44px row heights, unboxed metadata, tabular numbers) */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-slate-800 bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              <th className="py-3 px-4 font-semibold">Expense ID & Submitter</th>
              <th className="py-3 px-4 font-semibold">Merchant & Category</th>
              <th
                className="py-3 px-4 font-semibold cursor-pointer hover:text-white"
                onClick={() => toggleSort('date')}
              >
                <div className="flex items-center gap-1">
                  <span>Date</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th className="py-3 px-4 font-semibold">Department / Cost Center</th>
              <th
                className="py-3 px-4 font-semibold text-right cursor-pointer hover:text-white"
                onClick={() => toggleSort('amount')}
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Amount ({tenant.currency})</span>
                  <ArrowUpDown className="h-3 w-3" />
                </div>
              </th>
              <th className="py-3 px-4 font-semibold">Policy Status</th>
              <th className="py-3 px-4 font-semibold">Workflow Gate</th>
              <th className="py-3 px-4 text-right font-semibold">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredExpenses.length === 0 ? (
              <tr>
                <td colSpan={8} className="py-12 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <FileText className="h-8 w-8 text-slate-600 mb-2" />
                    <p className="text-sm font-medium text-slate-400">No expenses found matching filter criteria</p>
                    <button
                      onClick={onOpenScanner}
                      className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 cursor-pointer"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      <span>Scan & Upload First Receipt</span>
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              filteredExpenses.map((exp) => {
                const currentStep = exp.workflow.steps.find((s) => s.status === 'ACTIVE');
                const isCompliant = exp.policyStatus === 'COMPLIANT';

                return (
                  <tr
                    key={exp.id}
                    onClick={() => onSelectExpense(exp)}
                    className="group hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    {/* Expense ID & Submitter */}
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-indigo-400 group-hover:text-indigo-300">
                        {exp.expenseNumber}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span>{exp.submitterName}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-500">{exp.submitterRole}</span>
                      </div>
                    </td>

                    {/* Merchant & Category */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-200">{exp.merchant}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span>{exp.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono text-slate-400">{exp.glAccount.split(' - ')[0]}</span>
                      </div>
                    </td>

                    {/* Date */}
                    <td className="py-3 px-4 font-mono text-slate-300 tabular-nums">
                      {exp.date}
                    </td>

                    {/* Department / Cost Center */}
                    <td className="py-3 px-4">
                      <div className="text-slate-300">{exp.department}</div>
                      <div className="text-[11px] font-mono text-slate-500 mt-0.5">{exp.costCenter}</div>
                    </td>

                    {/* Amount */}
                    <td className="py-3 px-4 text-right font-mono font-semibold tabular-nums text-white">
                      ${exp.amount.toFixed(2)}
                    </td>

                    {/* Policy Status: Zero-Pill Unboxed Text */}
                    <td className="py-3 px-4">
                      {isCompliant ? (
                        <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-medium">
                          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                          <span>Compliant</span>
                        </div>
                      ) : (
                        <div className="flex items-start gap-1.5 text-amber-400 text-xs">
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                          <div>
                            <span className="font-medium">Policy Flag</span>
                            <span className="block text-[10px] text-slate-400 font-normal truncate max-w-[140px]">
                              {exp.policyFlags[0] || 'Requires Review'}
                            </span>
                          </div>
                        </div>
                      )}
                    </td>

                    {/* Workflow Step */}
                    <td className="py-3 px-4">
                      <div className="text-xs text-slate-300">
                        {exp.status === 'ERP_SYNCED' ? (
                          <span className="text-indigo-400 font-mono flex items-center gap-1">
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                            {tenant.erpType === 'sap' ? 'SAP Posted' : 'NetSuite Posted'}
                          </span>
                        ) : currentStep ? (
                          <span className="text-slate-300">
                            {currentStep.title}
                          </span>
                        ) : (
                          <span className="text-slate-500">{exp.status}</span>
                        )}
                      </div>
                      <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                        {exp.workflow.workflowId}
                      </div>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1 text-slate-400 group-hover:text-indigo-400 font-medium text-xs">
                        <span>Details</span>
                        <ChevronRight className="h-3.5 w-3.5" />
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
