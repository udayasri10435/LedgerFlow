import React, { useState, useRef } from 'react';
import { Tenant, User, Expense, Receipt, ReceiptLineItem } from '../types';
import {
  ScanLine,
  Upload,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  X,
  FileText,
  DollarSign,
  Building,
  Calendar,
  Layers,
  ArrowRight,
  ShieldAlert,
  Loader2
} from 'lucide-react';

interface ReceiptScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenant: Tenant;
  currentUser: User;
  onExpenseCreated: (expense: Expense) => void;
}

export const ReceiptScannerModal: React.FC<ReceiptScannerModalProps> = ({
  isOpen,
  onClose,
  tenant,
  currentUser,
  onExpenseCreated,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'upload'>('presets');
  const [selectedPreset, setSelectedPreset] = useState<string>('dinner');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanSource, setScanSource] = useState<string>('preset_verified');
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);

  // Extracted data state
  const [merchant, setMerchant] = useState<string>("Ruth's Prime Steakhouse");
  const [address, setAddress] = useState<string>("400 California St, San Francisco, CA");
  const [expenseDate, setExpenseDate] = useState<string>("2026-09-24");
  const [currency, setCurrency] = useState<string>(tenant.currency);
  const [subtotal, setSubtotal] = useState<number>(218.00);
  const [tax, setTax] = useState<number>(18.53);
  const [tip, setTip] = useState<number>(40.00);
  const [total, setTotal] = useState<number>(276.53);
  const [paymentMethod, setPaymentMethod] = useState<string>("Visa ending in 4829");
  const [category, setCategory] = useState<string>("Meals & Entertainment");
  const [glAccount, setGlAccount] = useState<string>("6100 - Meals & Entertainment");
  const [selectedCostCenter, setSelectedCostCenter] = useState<string>(tenant.costCenters[0]?.code || "CC-101");
  const [notes, setNotes] = useState<string>("Client engineering strategy dinner with prospective hire.");
  const [lineItems, setLineItems] = useState<ReceiptLineItem[]>([
    { id: "li_1", name: "Bone-in Ribeye 16oz", qty: 2, unitPrice: 68.00, total: 136.00, category: "Food" },
    { id: "li_2", name: "Cabernet Sauvignon (Bottle)", qty: 1, unitPrice: 62.00, total: 62.00, category: "Alcohol", glAccount: "6200" },
    { id: "li_3", name: "Creamed Spinach", qty: 1, unitPrice: 20.00, total: 20.00, category: "Food" }
  ]);
  const [policyFlags, setPolicyFlags] = useState<string[]>([
    "Per-meal threshold exceeded ($85 limit per attendee)",
    "Alcohol line item detected ($62.00) - routed to Entertainment GL 6200"
  ]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handlePresetSelect = async (presetKey: string) => {
    setSelectedPreset(presetKey);
    setIsScanning(true);
    try {
      const res = await fetch('/api/ocr/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ presetId: presetKey })
      });
      const data = await res.json();
      if (data.success && data.data) {
        populateFields(data.data, data.source);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const populateFields = (data: any, source: string) => {
    setScanSource(source);
    setMerchant(data.merchant || "Unknown Merchant");
    setAddress(data.address || "");
    setExpenseDate(data.date || new Date().toISOString().split('T')[0]);
    setCurrency(data.currency || tenant.currency);
    setSubtotal(data.subtotal || 0);
    setTax(data.tax || 0);
    setTip(data.tip || 0);
    setTotal(data.total || 0);
    setPaymentMethod(data.paymentMethod || "Corporate Card");
    setCategory(data.category || "General Expense");
    setGlAccount(data.glAccountCode || "6000 - General Operating");
    if (data.lineItems && Array.isArray(data.lineItems)) {
      setLineItems(
        data.lineItems.map((item: any, idx: number) => ({
          id: `li_${idx + 1}`,
          name: item.name,
          qty: item.qty || 1,
          unitPrice: item.unitPrice || item.total,
          total: item.total,
          category: item.category || "General",
          glAccount: item.glAccount
        }))
      );
    }
    if (data.policyViolations && Array.isArray(data.policyViolations)) {
      setPolicyFlags(data.policyViolations.map((v: any) => `${v.ruleName}: ${v.message}`));
    } else {
      setPolicyFlags([]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      setUploadedImagePreview(base64Data);
      setIsScanning(true);

      try {
        const res = await fetch('/api/ocr/scan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Data,
            mimeType: file.type,
            merchantHint: file.name
          })
        });
        const data = await res.json();
        if (data.success && data.data) {
          populateFields(data.data, data.source);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsScanning(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = () => {
    const expenseNum = `EXP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const workflowId = `wf_${expenseNum.toLowerCase()}`;
    const runId = `run_${Date.now().toString(36)}`;

    const newReceipt: Receipt = {
      id: `rcpt_${Date.now()}`,
      merchant,
      address,
      date: expenseDate,
      currency,
      subtotal,
      tax,
      tip,
      total,
      paymentMethod,
      category,
      glAccountCode: glAccount,
      lineItems,
      policyViolations: policyFlags.map((p, idx) => ({
        ruleId: `POL-00${idx + 1}`,
        ruleName: "Policy Evaluation",
        severity: "WARNING",
        message: p,
        actionRequired: "Approval Required"
      })),
      confidenceScore: 0.98,
      rawImageUrl: uploadedImagePreview || undefined,
      verified: true,
      sha256Hash: `hash_${Date.now()}_sha256`
    };

    const hasViolations = policyFlags.length > 0;

    const newExpense: Expense = {
      id: `exp_${Date.now()}`,
      expenseNumber: expenseNum,
      tenantId: tenant.id,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      submitterRole: currentUser.title,
      department: currentUser.department,
      costCenter: selectedCostCenter,
      merchant,
      date: expenseDate,
      amount: total,
      currency: currency as any,
      category,
      glAccount,
      status: 'PENDING_APPROVAL',
      policyStatus: hasViolations ? 'FLAGGED' : 'COMPLIANT',
      policyFlags,
      notes,
      receipt: newReceipt,
      paymentSource: paymentMethod.toLowerCase().includes('card') ? 'corporate_card' : 'out_of_pocket',
      workflow: {
        workflowId,
        runId,
        taskQueue: 'finance-approvals-queue',
        workflowType: 'StandardExpenseWorkflow',
        status: 'WAITING_APPROVAL',
        currentStepIndex: 1,
        startedAt: new Date().toISOString(),
        timeoutSeconds: 86400,
        retryCount: 0,
        canCompensate: true,
        steps: [
          {
            id: 'step_1',
            stepNumber: 1,
            title: 'Automated Policy OCR Validation',
            roleRequired: 'employee',
            status: 'COMPLETED',
            assignedToName: 'Temporal Rule Engine',
            completedAt: new Date().toISOString(),
            note: hasViolations ? `Validated with ${policyFlags.length} policy warnings flagged.` : 'All OCR receipt items 100% compliant with company rules.'
          },
          {
            id: 'step_2',
            stepNumber: 2,
            title: 'Direct Manager Sign-off',
            roleRequired: 'manager',
            status: 'ACTIVE',
            assignedToName: 'Sarah Jenkins',
            note: hasViolations ? 'Reviewing flagged policy exceptions and client notes.' : 'Pending standard line-item sign-off.'
          },
          {
            id: 'step_3',
            stepNumber: 3,
            title: 'Finance Controller Review',
            roleRequired: 'controller',
            status: 'PENDING',
            assignedToName: 'Marcus Vance'
          },
          {
            id: 'step_4',
            stepNumber: 4,
            title: `${tenant.erpType === 'sap' ? 'SAP S/4HANA' : 'NetSuite'} ERP Journal Sync`,
            roleRequired: 'controller',
            status: 'PENDING',
            assignedToName: 'ERP Dispatch Worker'
          }
        ],
        historyEvents: [
          {
            eventId: 1,
            eventType: 'WorkflowExecutionStarted',
            timestamp: new Date().toISOString(),
            details: `Temporal state machine initialized for ${expenseNum}.`,
            status: 'SUCCESS'
          },
          {
            eventId: 2,
            eventType: 'ActivityTaskCompleted [OCRValidation]',
            timestamp: new Date().toISOString(),
            details: `Scanned via ${scanSource}. Extracted ${lineItems.length} line items.`,
            status: hasViolations ? 'WARNING' : 'SUCCESS'
          }
        ]
      }
    };

    onExpenseCreated(newExpense);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative flex max-h-[92vh] w-full max-w-5xl flex-col rounded-xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400">
              <ScanLine className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">
                Intelligent OCR Receipt Scanner
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>{tenant.name}</span>
                <span aria-hidden="true">·</span>
                <span>Powered by Gemini 3.8 Flash Multimodal</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-emerald-400">Policy Engine Live</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body: Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 overflow-y-auto min-h-0 flex-1 divide-y lg:divide-y-0 lg:divide-x divide-slate-800">
          {/* Left Column: Preset Selector & Receipt Visualizer (5 Cols) */}
          <div className="lg:col-span-5 p-6 bg-slate-950/40 flex flex-col gap-4 overflow-y-auto">
            {/* Mode Tabs */}
            <div className="flex rounded-lg bg-slate-900 p-1 border border-slate-800">
              <button
                onClick={() => setActiveTab('presets')}
                className={`flex-1 rounded-md py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'presets' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sample Enterprise Receipts
              </button>
              <button
                onClick={() => setActiveTab('upload')}
                className={`flex-1 rounded-md py-1.5 text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'upload' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Upload File / Image
              </button>
            </div>

            {/* Presets Grid */}
            {activeTab === 'presets' ? (
              <div className="space-y-2">
                <p className="text-xs text-slate-400">
                  Select a pre-loaded receipt to evaluate OCR extraction & policy detection:
                </p>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { id: 'dinner', label: "Ruth's Steakhouse ($276.53)", sub: "Dining & Alcohol Policy Flags", alert: true },
                    { id: 'delta_flight', label: "Delta Air Lines DL1842 ($530.78)", sub: "Compliant Travel Airfare", alert: false },
                    { id: 'aws_cloud', label: "AWS Cloud Infrastructure ($1,240.50)", sub: "Stripe Virtual Card Match", alert: false },
                    { id: 'hardware_dock', label: "Apple Hardware Dock ($326.66)", sub: "Equipment Stipend Limit", alert: true },
                    { id: 'uber_ride', label: "Uber Airport Comfort ($53.68)", sub: "Compliant Ground Travel", alert: false },
                  ].map((p) => (
                    <button
                      key={p.id}
                      onClick={() => handlePresetSelect(p.id)}
                      className={`flex items-start justify-between rounded-lg p-3 text-left transition-all border cursor-pointer ${
                        selectedPreset === p.id
                          ? 'border-indigo-500 bg-indigo-950/20 text-white'
                          : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-semibold">{p.label}</div>
                        <div className="text-[11px] text-slate-400">{p.sub}</div>
                      </div>
                      {p.alert && (
                        <span className="text-[10px] font-mono text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded">
                          Policy Flag
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-slate-700 bg-slate-900/40 p-8 text-center hover:border-indigo-500 hover:bg-slate-900/80 transition-all cursor-pointer"
                >
                  <Upload className="h-8 w-8 text-slate-400 mb-2" />
                  <p className="text-xs font-medium text-slate-200">
                    Click to upload or drag & drop receipt
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    PNG, JPEG, WebP, or PDF up to 15MB
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </div>
                {uploadedImagePreview && (
                  <div className="rounded-lg border border-slate-800 overflow-hidden bg-black/40 p-2">
                    <img
                      src={uploadedImagePreview}
                      alt="Uploaded Receipt"
                      className="max-h-48 w-full object-contain rounded"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Authentic Monospace Dot-Matrix Thermal Receipt Visualizer */}
            <div className="relative mt-2 rounded-lg bg-neutral-900/90 p-4 border border-neutral-700/60 font-mono text-xs text-neutral-300 shadow-inner">
              <div className="text-center border-b border-dashed border-neutral-700 pb-3">
                <div className="font-bold text-sm tracking-wider uppercase text-neutral-100">
                  {merchant}
                </div>
                <div className="text-[10px] text-neutral-400">{address}</div>
                <div className="text-[10px] text-neutral-400 mt-1">
                  DATE: {expenseDate} · CURRENCY: {currency}
                </div>
              </div>

              {/* Receipt Line Items Preview */}
              <div className="py-3 space-y-1.5 border-b border-dashed border-neutral-700">
                {lineItems.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-start text-[11px]">
                    <span className="truncate pr-2">
                      {item.qty}x {item.name}
                    </span>
                    <span className="font-mono tabular-nums text-neutral-200 shrink-0">
                      ${item.total.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="pt-3 space-y-1 text-[11px]">
                <div className="flex justify-between text-neutral-400">
                  <span>SUBTOTAL</span>
                  <span className="tabular-nums">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>TAX</span>
                  <span className="tabular-nums">${tax.toFixed(2)}</span>
                </div>
                {tip > 0 && (
                  <div className="flex justify-between text-neutral-400">
                    <span>TIP / GRATUITY</span>
                    <span className="tabular-nums">${tip.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-neutral-100 pt-1 border-t border-neutral-700 text-sm">
                  <span>TOTAL DUE</span>
                  <span className="tabular-nums text-indigo-400">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Barcode representation */}
              <div className="mt-4 pt-3 border-t border-dashed border-neutral-700 text-center">
                <div className="inline-block tracking-widest text-neutral-500 font-mono text-[9px]">
                  ||| | |||| | ||| |||| || | |||| |||
                </div>
                <div className="text-[9px] text-neutral-500 mt-0.5">
                  AUTH CODE: 894021 · OCR VERIFIED
                </div>
              </div>

              {/* Scanning Overlay indicator */}
              {isScanning && (
                <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs flex flex-col items-center justify-center rounded-lg gap-2 text-indigo-400">
                  <Loader2 className="h-6 w-6 animate-spin text-indigo-400" />
                  <span className="text-xs font-sans font-medium text-slate-200">
                    Gemini 3.8 Flash OCR Parsing...
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: OCR Extracted Fields & Policy Review (7 Cols) */}
          <div className="lg:col-span-7 p-6 flex flex-col gap-5 overflow-y-auto">
            {/* Engine Status Bar */}
            <div className="flex items-center justify-between rounded-lg bg-slate-950 p-3 border border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-indigo-400" />
                <span className="text-xs font-medium text-slate-300">
                  OCR Engine: <span className="font-mono text-white">{scanSource}</span>
                </span>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                Confidence: 99.2%
              </span>
            </div>

            {/* Policy Violations / Warnings Banner */}
            {policyFlags.length > 0 ? (
              <div className="rounded-lg border border-amber-500/30 bg-amber-950/20 p-3 text-xs">
                <div className="flex items-center gap-2 font-semibold text-amber-300">
                  <AlertTriangle className="h-4 w-4 text-amber-400" />
                  <span>Policy Engine Exception Flags ({policyFlags.length})</span>
                </div>
                <ul className="mt-2 space-y-1 text-slate-300 pl-6 list-disc text-[11px]">
                  {policyFlags.map((flag, i) => (
                    <li key={i}>{flag}</li>
                  ))}
                </ul>
                <div className="mt-2 text-[11px] text-amber-400/80">
                  Expense will route through secondary approval gate to Manager & Controller.
                </div>
              </div>
            ) : (
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/20 p-3 text-xs flex items-center gap-2 text-emerald-300">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span>100% Policy Compliant — Meets all per-diem and receipt threshold rules.</span>
              </div>
            )}

            {/* Form Fields Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-400 font-medium">Merchant Name</label>
                <input
                  type="text"
                  value={merchant}
                  onChange={(e) => setMerchant(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Expense Date</label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Total Amount ({currency})</label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-2 text-slate-500 font-mono">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={total}
                    onChange={(e) => setTotal(parseFloat(e.target.value) || 0)}
                    className="w-full rounded-md border border-slate-800 bg-slate-950 pl-7 pr-3 py-2 text-white focus:border-indigo-500 focus:outline-none font-mono tabular-nums text-sm font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-medium">Payment Method</label>
                <input
                  type="text"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer"
                >
                  <option value="Meals & Entertainment">Meals & Entertainment</option>
                  <option value="Airfare & Travel">Airfare & Travel</option>
                  <option value="Ground Transportation">Ground Transportation</option>
                  <option value="Cloud Infrastructure">Cloud Infrastructure</option>
                  <option value="Hardware & Peripherals">Hardware & Peripherals</option>
                  <option value="Client Entertainment">Client Entertainment</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-medium">Cost Center Allocation</label>
                <select
                  value={selectedCostCenter}
                  onChange={(e) => setSelectedCostCenter(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer font-mono"
                >
                  {tenant.costCenters.map((cc) => (
                    <option key={cc.code} value={cc.code}>
                      {cc.code} · {cc.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="text-slate-400 font-medium">GL Account Code (ERP Mapping)</label>
                <input
                  type="text"
                  value={glAccount}
                  onChange={(e) => setGlAccount(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none font-mono text-xs"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-slate-400 font-medium">Business Purpose & Client Justification</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Describe the business objective, attendees, and project affiliation..."
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none resize-none"
                />
              </div>
            </div>

            {/* Extracted Line Items Table */}
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-300">
                  Itemized Line Breakdown ({lineItems.length} items)
                </span>
                <span className="text-slate-500 text-[11px]">Auto-parsed by Multimodal OCR</span>
              </div>
              <div className="rounded-lg border border-slate-800 bg-slate-950/60 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-2 px-3 font-medium">Item Description</th>
                      <th className="py-2 px-3 font-medium text-center">Qty</th>
                      <th className="py-2 px-3 font-medium text-right">Price</th>
                      <th className="py-2 px-3 font-medium text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {lineItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/40">
                        <td className="py-2 px-3 font-sans text-slate-200">
                          {item.name}
                          {item.category === 'Alcohol' && (
                            <span className="ml-2 font-mono text-[10px] text-amber-400 bg-amber-400/10 px-1 py-0.5 rounded">
                              Alcohol (GL 6200)
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-center text-slate-400">{item.qty}</td>
                        <td className="py-2 px-3 text-right text-slate-400 tabular-nums">
                          ${item.unitPrice.toFixed(2)}
                        </td>
                        <td className="py-2 px-3 text-right text-slate-100 font-semibold tabular-nums">
                          ${item.total.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Submit Action */}
            <div className="mt-auto pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-800 bg-slate-900 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors cursor-pointer"
              >
                <span>Confirm & Initiate Temporal Workflow</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
