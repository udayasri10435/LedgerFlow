import React, { useState } from 'react';
import { Expense, Tenant, User, Receipt } from '../types';
import {
  Plus,
  ScanLine,
  X,
  FileText,
  DollarSign,
  Building,
  Calendar,
  Layers,
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface NewExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenant: Tenant;
  currentUser: User;
  onExpenseCreated: (expense: Expense) => void;
  onOpenScanner: () => void;
}

export const NewExpenseModal: React.FC<NewExpenseModalProps> = ({
  isOpen,
  onClose,
  tenant,
  currentUser,
  onExpenseCreated,
  onOpenScanner,
}) => {
  const [merchant, setMerchant] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [category, setCategory] = useState('Meals & Entertainment');
  const [glAccount, setGlAccount] = useState('6100 - Meals & Entertainment');
  const [costCenter, setCostCenter] = useState(tenant.costCenters[0]?.code || 'CC-101');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');
  const [hasReceipt, setHasReceipt] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!merchant || amount <= 0) return;

    const expenseNum = `EXP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const workflowId = `wf_${expenseNum.toLowerCase()}`;
    const runId = `run_${Date.now().toString(36)}`;

    // Evaluate policies
    const policyFlags: string[] = [];
    if (amount > 85 && category.includes('Meal')) {
      policyFlags.push('Per-meal limit ($85) exceeded');
    }
    if (amount >= 25 && !hasReceipt) {
      policyFlags.push('Missing mandatory receipt (>= $25 threshold)');
    }

    const newExpense: Expense = {
      id: `exp_${Date.now()}`,
      expenseNumber: expenseNum,
      tenantId: tenant.id,
      submitterId: currentUser.id,
      submitterName: currentUser.name,
      submitterRole: currentUser.title,
      department: currentUser.department,
      costCenter,
      merchant,
      date: expenseDate,
      amount,
      currency: tenant.currency,
      category,
      glAccount,
      status: 'PENDING_APPROVAL',
      policyStatus: policyFlags.length > 0 ? 'FLAGGED' : 'COMPLIANT',
      policyFlags,
      notes,
      paymentSource: 'out_of_pocket',
      workflow: {
        workflowId,
        runId,
        taskQueue: 'finance-approvals-queue',
        workflowType: 'StandardExpenseWorkflow',
        status: 'WAITING_APPROVAL',
        currentStepIndex: 1,
        startedAt: new Date().toISOString(),
        timeoutSeconds: 86400,
        retryCount: 0,
        canCompensate: true,
        steps: [
          {
            id: 's1',
            stepNumber: 1,
            title: 'Automated Policy Check',
            roleRequired: 'employee',
            status: 'COMPLETED',
            assignedToName: 'Temporal Rule Engine',
            completedAt: new Date().toISOString(),
            note: policyFlags.length > 0 ? `Triggered: ${policyFlags.join(', ')}` : '100% Policy Compliant'
          },
          {
            id: 's2',
            stepNumber: 2,
            title: 'Direct Manager Approval',
            roleRequired: 'manager',
            status: 'ACTIVE',
            assignedToName: 'Sarah Jenkins',
            note: 'Pending manager review.'
          },
          {
            id: 's3',
            stepNumber: 3,
            title: 'Finance Controller Review',
            roleRequired: 'controller',
            status: 'PENDING',
            assignedToName: 'Marcus Vance'
          },
          {
            id: 's4',
            stepNumber: 4,
            title: `${tenant.erpType === 'sap' ? 'SAP S/4HANA' : 'NetSuite'} ERP Journal Post`,
            roleRequired: 'controller',
            status: 'PENDING',
            assignedToName: 'ERP Dispatch Worker'
          }
        ],
        historyEvents: [
          {
            eventId: 1,
            eventType: 'WorkflowExecutionStarted',
            timestamp: new Date().toISOString(),
            details: `Workflow initialized for ${expenseNum}.`,
            status: 'SUCCESS'
          }
        ]
      }
    };

    onExpenseCreated(newExpense);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="relative w-full max-w-lg rounded-xl border border-slate-800 bg-slate-900 p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-indigo-400" />
            <h3 className="text-base font-semibold text-white">Create New Expense Claim</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* OCR scanner promotion box */}
        <div
          onClick={() => {
            onClose();
            onOpenScanner();
          }}
          className="flex items-center justify-between rounded-lg border border-indigo-500/30 bg-indigo-950/30 p-3 hover:bg-indigo-950/50 cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <ScanLine className="h-5 w-5 text-indigo-400" />
            <div>
              <div className="text-xs font-semibold text-white">Have an expense receipt?</div>
              <div className="text-[11px] text-slate-400">Use Gemini 3.8 Flash OCR to extract line items automatically</div>
            </div>
          </div>
          <span className="text-xs text-indigo-400 font-semibold flex items-center gap-1">
            <span>Open Scanner</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-slate-400 font-medium">Merchant / Vendor Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Delta Air Lines, Ruth's Steakhouse, AWS..."
              value={merchant}
              onChange={(e) => setMerchant(e.target.value)}
              className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 font-medium">Total Amount ({tenant.currency})</label>
              <input
                type="number"
                step="0.01"
                required
                placeholder="0.00"
                value={amount || ''}
                onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono tabular-nums focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-400 font-medium">Date</label>
              <input
                type="date"
                required
                value={expenseDate}
                onChange={(e) => setExpenseDate(e.target.value)}
                className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 font-medium">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer"
              >
                <option value="Meals & Entertainment">Meals & Entertainment</option>
                <option value="Airfare & Travel">Airfare & Travel</option>
                <option value="Ground Transportation">Ground Transportation</option>
                <option value="Cloud Infrastructure">Cloud Infrastructure</option>
                <option value="Hardware & Peripherals">Hardware & Peripherals</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 font-medium">Cost Center</label>
              <select
                value={costCenter}
                onChange={(e) => setCostCenter(e.target.value)}
                className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer font-mono"
              >
                {tenant.costCenters.map((cc) => (
                  <option key={cc.code} value={cc.code}>
                    {cc.code} · {cc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-slate-400 font-medium">GL Account Mapping</label>
            <input
              type="text"
              value={glAccount}
              onChange={(e) => setGlAccount(e.target.value)}
              className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white font-mono text-xs focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-slate-400 font-medium">Business Purpose / Notes</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="State client purpose or business project..."
              className="mt-1 w-full rounded-md border border-slate-800 bg-slate-950 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none resize-none"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md border border-slate-800 px-3 py-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-md bg-indigo-600 px-4 py-1.5 font-semibold text-white hover:bg-indigo-500 transition-colors cursor-pointer"
            >
              Submit & Start Workflow
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
