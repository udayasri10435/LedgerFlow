import React from 'react';
import { Tenant, User, UserRole } from '../types';
import { ShieldCheck, Plus, Building2, UserCircle2 } from 'lucide-react';

interface TopBarProps {
  currentTenant: Tenant;
  tenants: Tenant[];
  onSelectTenant: (tenant: Tenant) => void;
  currentUser: User;
  users: User[];
  onSelectUser: (user: User) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenNewExpense: () => void;
  pendingCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentTenant,
  tenants,
  onSelectTenant,
  currentUser,
  users,
  onSelectUser,
  activeTab,
  onSelectTab,
  onOpenNewExpense,
  pendingCount,
}) => {
  const navItems = [
    { id: 'expenses', label: 'Expenses' },
    { id: 'workflows', label: 'Workflows', badge: pendingCount > 0 ? pendingCount : undefined },
    { id: 'policies', label: 'Policy Engine' },
    { id: 'erp', label: 'ERP Sync' },
    { id: 'cards', label: 'Cards & Plaid' },
    { id: 'audit', label: 'SOC 2 Vault' },
  ];

  return (
    <header className="sticky top-0 z-30 flex h-14 w-full items-center justify-between border-b border-slate-800 bg-slate-950/90 px-6 backdrop-blur-md">
      {/* Zone 1: Single text element wordmark with subtle SOC 2 trust anchor */}
      <div className="flex items-center gap-3">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectTab('expenses');
          }}
          className="text-lg font-bold tracking-tight text-white hover:text-indigo-400 transition-colors"
        >
          LedgerFlow
        </a>
        <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-emerald-400/90 font-mono">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
          SOC 2 Type II
        </span>
      </div>

      {/* Zone 2: 4-6 clean text navigation links */}
      <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`relative py-1 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
              {item.badge !== undefined && (
                <span className="ml-1.5 inline-block text-[10px] font-mono text-amber-400">
                  [{item.badge}]
                </span>
              )}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: 1-2 primary actions (Tenant & Role switchers + Submit button) */}
      <div className="flex items-center gap-3">
        {/* Tenant selector */}
        <div className="relative flex items-center gap-1.5 text-xs text-slate-300 bg-slate-900 border border-slate-800 rounded-md px-2.5 py-1.5">
          <Building2 className="h-3.5 w-3.5 text-slate-400 shrink-0" />
          <select
            value={currentTenant.id}
            onChange={(e) => {
              const selected = tenants.find((t) => t.id === e.target.value);
              if (selected) onSelectTenant(selected);
            }}
            aria-label="Select Company Tenant"
            className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
          >
            {tenants.map((t) => (
              <option key={t.id} value={t.id} className="bg-slate-900 text-slate-100">
                {t.name} ({t.currency})
              </option>
            ))}
          </select>
        </div>

        {/* Role Switcher */}
        <div className="relative flex items-center gap-1.5 text-xs text-slate-300 bg-slate-900 border border-slate-800 rounded-md px-2.5 py-1.5">
          <UserCircle2 className="h-3.5 w-3.5 text-indigo-400 shrink-0" />
          <select
            value={currentUser.id}
            onChange={(e) => {
              const selected = users.find((u) => u.id === e.target.value);
              if (selected) onSelectUser(selected);
            }}
            aria-label="Switch User Role"
            className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
          >
            {users.map((u) => (
              <option key={u.id} value={u.id} className="bg-slate-900 text-slate-100">
                {u.name} ({u.role.toUpperCase()})
              </option>
            ))}
          </select>
        </div>

        {/* Primary CTA */}
        <button
          onClick={onOpenNewExpense}
          className="flex items-center gap-1.5 rounded-md bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 transition-colors whitespace-nowrap cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>New Expense</span>
        </button>
      </div>
    </header>
  );
};
