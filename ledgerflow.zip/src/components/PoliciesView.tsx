import React, { useState } from 'react';
import { PolicyRule, Tenant, User } from '../types';
import {
  ShieldAlert,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Play,
  Plus,
  Scale,
  Settings,
  Sparkles,
  Info
} from 'lucide-react';

interface PoliciesViewProps {
  policies: PolicyRule[];
  tenant: Tenant;
  currentUser: User;
  onUpdatePolicy: (updated: PolicyRule) => void;
}

export const PoliciesView: React.FC<PoliciesViewProps> = ({
  policies,
  tenant,
  currentUser,
  onUpdatePolicy,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Policy Simulator Sandbox State
  const [simAmount, setSimAmount] = useState<number>(120);
  const [simCategory, setSimCategory] = useState<string>('MEALS');
  const [simHasAlcohol, setSimHasAlcohol] = useState<boolean>(true);
  const [simIsWeekend, setSimIsWeekend] = useState<boolean>(false);
  const [simHasReceipt, setSimHasReceipt] = useState<boolean>(true);

  // Evaluate simulation against active policies
  const simulationResults = React.useMemo(() => {
    const triggered: { rule: PolicyRule; message: string; severity: string }[] = [];

    policies.forEach((rule) => {
      if (!rule.active) return;

      if (rule.ruleType === 'PER_DIEM' && simCategory === 'MEALS' && simAmount > (rule.limitAmount || 85)) {
        triggered.push({
          rule,
          message: `Amount $${simAmount.toFixed(2)} exceeds meal limit of $${rule.limitAmount}. Attendee list required.`,
          severity: rule.severity
        });
      }

      if (rule.ruleType === 'RECEIPT_THRESHOLD' && simAmount >= (rule.limitAmount || 25) && !simHasReceipt) {
        triggered.push({
          rule,
          message: `Transactions >= $${rule.limitAmount} strictly require verified itemized receipt attachment.`,
          severity: 'VIOLATION'
        });
      }

      if (rule.ruleType === 'ALCOHOL' && simHasAlcohol) {
        triggered.push({
          rule,
          message: `Alcohol detected. Must be segregated to GL 6200 and routed to Department Director.`,
          severity: rule.severity
        });
      }

      if (rule.ruleType === 'WEEKEND' && simIsWeekend) {
        triggered.push({
          rule,
          message: `Transaction occurred on a weekend. Client justification note required.`,
          severity: rule.severity
        });
      }

      if (rule.ruleType === 'CAPEX' && simAmount >= (rule.limitAmount || 2500)) {
        triggered.push({
          rule,
          message: `CapEx threshold of $${rule.limitAmount} exceeded. VP Finance sign-off required.`,
          severity: rule.severity
        });
      }
    });

    return triggered;
  }, [policies, simAmount, simCategory, simHasAlcohol, simIsWeekend, simHasReceipt]);

  const filteredPolicies = policies.filter((p) => {
    if (selectedCategory === 'ALL') return true;
    return p.category === selectedCategory;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white">Policy Engine & Compliance Guardrails</h2>
            <span className="font-mono text-xs text-indigo-400 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/40">
              SOC 2 CC6.8
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic rules executed in real-time by Temporal state machine prior to manager routing for {tenant.name}.
          </p>
        </div>

        {/* Filter categories */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          {['ALL', 'MEALS', 'TRAVEL', 'HARDWARE', 'AUDIT'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                selectedCategory === cat ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Active Policy Rules List (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Enforced Corporate Rules ({filteredPolicies.length})</span>
            <span className="font-mono text-emerald-400">Deterministic Engine Active</span>
          </div>

          <div className="space-y-3">
            {filteredPolicies.map((rule) => (
              <div
                key={rule.id}
                className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 transition-all hover:border-slate-700 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-indigo-400">{rule.code}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-xs font-semibold text-white">{rule.name}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {rule.description}
                    </p>
                  </div>

                  {/* Active Toggle */}
                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={rule.active}
                      onChange={(e) => onUpdatePolicy({ ...rule, active: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                  </label>
                </div>

                {/* Policy Metadata Footer */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px] font-mono">
                  <div className="flex items-center gap-2 text-slate-400">
                    <span>Severity:</span>
                    <span
                      className={
                        rule.severity === 'VIOLATION'
                          ? 'text-rose-400'
                          : rule.severity === 'WARNING'
                          ? 'text-amber-400'
                          : 'text-indigo-400'
                      }
                    >
                      {rule.severity}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>Approval Role: {rule.requiresApprovalRole.toUpperCase()}</span>
                  </div>

                  {rule.limitAmount !== undefined && (
                    <span className="text-slate-300 font-semibold tabular-nums">
                      Threshold: ${rule.limitAmount} USD
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Policy Simulation Sandbox (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Play className="h-4 w-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-white">Policy Engine Sandbox Simulator</h3>
            </div>
            <p className="text-xs text-slate-400">
              Simulate an expense submission to verify real-time policy detection triggers and routing logic:
            </p>

            {/* Simulation Controls */}
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-medium">Test Amount ($ USD)</label>
                <input
                  type="number"
                  value={simAmount}
                  onChange={(e) => setSimAmount(parseFloat(e.target.value) || 0)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-900 px-3 py-2 text-white font-mono tabular-nums text-sm font-semibold focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium">Category</label>
                <select
                  value={simCategory}
                  onChange={(e) => setSimCategory(e.target.value)}
                  className="mt-1 w-full rounded-md border border-slate-800 bg-slate-900 px-3 py-2 text-white focus:border-indigo-500 focus:outline-none cursor-pointer"
                >
                  <option value="MEALS">Meals & Client Dining</option>
                  <option value="TRAVEL">Airfare & Travel</option>
                  <option value="HARDWARE">Hardware & IT Equipment</option>
                  <option value="SOFTWARE">Cloud & SaaS Subscriptions</option>
                </select>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simHasAlcohol}
                    onChange={(e) => setSimHasAlcohol(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0"
                  />
                  <span>Includes Alcohol</span>
                </label>

                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simIsWeekend}
                    onChange={(e) => setSimIsWeekend(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0"
                  />
                  <span>Weekend Date</span>
                </label>

                <label className="flex items-center gap-2 text-slate-300 cursor-pointer col-span-2">
                  <input
                    type="checkbox"
                    checked={simHasReceipt}
                    onChange={(e) => setSimHasReceipt(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0"
                  />
                  <span>Has Verified Receipt Attached</span>
                </label>
              </div>
            </div>

            {/* Simulation Real-time Evaluation Results */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300">Live Policy Evaluation</span>
                <span className="font-mono text-[11px] text-slate-400">
                  {simulationResults.length === 0 ? 'Compliant' : `${simulationResults.length} Flags Triggered`}
                </span>
              </div>

              {simulationResults.length === 0 ? (
                <div className="rounded-lg bg-emerald-950/20 border border-emerald-500/30 p-3 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>No policy violations detected. Eligible for direct manager sign-off.</span>
                </div>
              ) : (
                <div className="space-y-2">
                  {simulationResults.map((res, i) => (
                    <div
                      key={i}
                      className="rounded-lg bg-amber-950/20 border border-amber-500/30 p-2.5 text-xs text-slate-200"
                    >
                      <div className="flex items-center gap-1.5 font-semibold text-amber-300 text-[11px]">
                        <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
                        <span>{res.rule.name}</span>
                      </div>
                      <div className="mt-1 text-[11px] text-slate-300 pl-5">
                        {res.message}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
