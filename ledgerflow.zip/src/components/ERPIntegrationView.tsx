import React, { useState } from 'react';
import { Tenant, Expense, User } from '../types';
import {
  Server,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  FileCode,
  Download,
  ExternalLink,
  Layers,
  ArrowRight,
  Database,
  Lock,
  Send,
  Loader2
} from 'lucide-react';

interface ERPIntegrationViewProps {
  tenant: Tenant;
  currentUser: User;
  expenses: Expense[];
  onExpensesSynced: (syncedIds: string[]) => void;
}

export const ERPIntegrationView: React.FC<ERPIntegrationViewProps> = ({
  tenant,
  currentUser,
  expenses,
  onExpensesSynced,
}) => {
  const [selectedSystem, setSelectedSystem] = useState<'netsuite' | 'sap'>(tenant.erpType === 'sap' ? 'sap' : 'netsuite');
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [latestSyncPayload, setLatestSyncPayload] = useState<any>(null);
  const [syncStatusMessage, setSyncStatusMessage] = useState<string | null>(null);

  // Ready to sync expenses (approved or pending erp)
  const pendingSyncExpenses = expenses.filter(
    (e) => e.tenantId === tenant.id && (e.status === 'APPROVED' || e.status === 'PENDING_APPROVAL')
  );

  const syncedExpenses = expenses.filter(
    (e) => e.tenantId === tenant.id && e.status === 'ERP_SYNCED'
  );

  const handleTriggerSync = async () => {
    setIsSyncing(true);
    setSyncStatusMessage(null);

    try {
      const expIds = pendingSyncExpenses.map((e) => e.id);
      const res = await fetch('/api/erp/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetErp: selectedSystem,
          expenseIds: expIds,
          tenantId: tenant.id
        })
      });
      const data = await res.json();
      if (data.success) {
        setLatestSyncPayload(data.payload);
        setSyncStatusMessage(`Successfully posted journal entries to ${data.target}. Status: Confirmed.`);
        onExpensesSynced(expIds);
      }
    } catch (err) {
      console.error(err);
      setSyncStatusMessage('Error dispatching to ERP gateway. Check network connection.');
    } finally {
      setIsSyncing(false);
    }
  };

  const downloadJsonExport = () => {
    const exportData = {
      tenant: tenant.name,
      exportDate: new Date().toISOString(),
      targetSystem: selectedSystem === 'netsuite' ? 'NetSuite SuiteTalk REST' : 'SAP S/4HANA OData',
      records: expenses.filter((e) => e.tenantId === tenant.id)
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `erp_export_${tenant.code}_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white">Enterprise ERP Ledger Integration Hub</h2>
            <span className="font-mono text-xs text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
              OAuth 2.0 / Mutual TLS Verified
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automated two-way journal entry posting, general ledger distribution, and subsidiary cost-center allocation.
          </p>
        </div>

        {/* System Selector Switch */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setSelectedSystem('netsuite')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              selectedSystem === 'netsuite' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Oracle NetSuite SuiteTalk
          </button>
          <button
            onClick={() => setSelectedSystem('sap')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              selectedSystem === 'sap' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            SAP S/4HANA OData
          </button>
        </div>
      </div>

      {/* Integration Status Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-1.5">
          <div className="text-slate-500 font-sans uppercase text-[11px]">Subsidiary / Company Code</div>
          <div className="text-white text-sm font-semibold">
            {selectedSystem === 'netsuite' ? '1 (Acme US Holding Inc)' : 'DE10 (Apex Logistics DE)'}
          </div>
          <div className="text-slate-400 text-[11px]">Currency: {tenant.currency} · Fiscal Year: 2026</div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-1.5">
          <div className="text-slate-500 font-sans uppercase text-[11px]">Target Record Entity</div>
          <div className="text-white text-sm font-semibold">
            {selectedSystem === 'netsuite' ? 'ExpenseReport / VendorBill' : 'BAPI_ACC_DOCUMENT_POST (KR)'}
          </div>
          <div className="text-emerald-400 text-[11px] flex items-center gap-1">
            <CheckCircle2 className="h-3 w-3" /> REST Web Services 2026.1 Active
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-4 space-y-1.5">
          <div className="text-slate-500 font-sans uppercase text-[11px]">Sync Queue Status</div>
          <div className="text-amber-400 text-sm font-semibold">
            {pendingSyncExpenses.length} Reports Ready for Posting
          </div>
          <div className="text-slate-400 text-[11px]">
            {syncedExpenses.length} Synced to Ledger
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sync Queue & Trigger (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">Pending ERP Batch Queue</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Approved expense reports awaiting journal entry creation in {selectedSystem === 'netsuite' ? 'NetSuite' : 'SAP'}.
                </p>
              </div>
              <button
                onClick={handleTriggerSync}
                disabled={isSyncing || pendingSyncExpenses.length === 0}
                className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow hover:bg-indigo-500 disabled:opacity-50 transition-colors cursor-pointer"
              >
                {isSyncing ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>Dispatching...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-3.5 w-3.5" />
                    <span>Post Batch to ERP</span>
                  </>
                )}
              </button>
            </div>

            {syncStatusMessage && (
              <div className="rounded-lg bg-emerald-950/20 border border-emerald-500/30 p-3 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span>{syncStatusMessage}</span>
              </div>
            )}

            {/* Queue List */}
            <div className="rounded-lg border border-slate-800 bg-slate-950 divide-y divide-slate-800/80 overflow-hidden text-xs">
              {pendingSyncExpenses.length === 0 ? (
                <div className="p-8 text-center text-slate-500">
                  All approved expenses have been posted to {selectedSystem === 'netsuite' ? 'NetSuite' : 'SAP'}.
                </div>
              ) : (
                pendingSyncExpenses.map((exp) => (
                  <div key={exp.id} className="p-3.5 flex items-center justify-between">
                    <div>
                      <div className="font-mono font-semibold text-white">{exp.expenseNumber}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {exp.merchant} · {exp.glAccount.split(' - ')[0]} · {exp.costCenter}
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <div className="text-white font-semibold tabular-nums">${exp.amount.toFixed(2)}</div>
                      <span className="text-[10px] text-amber-400">Queue: Awaiting Dispatch</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Export buttons */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-800">
              <span className="text-xs text-slate-400">Compliance & Auditor File Formats:</span>
              <button
                onClick={downloadJsonExport}
                className="flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition-colors font-mono cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export Ledger Payload (JSON)</span>
              </button>
            </div>
          </div>

          {/* GL Chart of Accounts Mapping Table */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Configured GL Account Code Mappings
            </h4>
            <div className="rounded-lg border border-slate-800 bg-slate-950 overflow-hidden text-xs font-mono">
              <table className="w-full text-left">
                <thead className="bg-slate-900 text-slate-400 text-[11px] border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-3">Expense Category</th>
                    <th className="py-2 px-3">GL Account Code</th>
                    <th className="py-2 px-3">Debit / Credit Type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300 text-[11px]">
                  <tr>
                    <td className="py-2 px-3 font-sans">Meals & Entertainment</td>
                    <td className="py-2 px-3 text-indigo-400">6100 - Meals Operating</td>
                    <td className="py-2 px-3 text-emerald-400">Debit (Expense)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Alcohol / Client Entertainment</td>
                    <td className="py-2 px-3 text-indigo-400">6200 - Client Ent Non-Ded</td>
                    <td className="py-2 px-3 text-emerald-400">Debit (Expense)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Airfare & Travel</td>
                    <td className="py-2 px-3 text-indigo-400">6250 - Travel Commercial Air</td>
                    <td className="py-2 px-3 text-emerald-400">Debit (Expense)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Cloud Infrastructure (AWS)</td>
                    <td className="py-2 px-3 text-indigo-400">6300 - Hosting Infrastructure</td>
                    <td className="py-2 px-3 text-emerald-400">Debit (Expense)</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-sans">Corporate Card Clearing</td>
                    <td className="py-2 px-3 text-indigo-400">2000 - AP Corporate Card</td>
                    <td className="py-2 px-3 text-amber-400">Credit (Liability)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Live Payload Inspector (6 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileCode className="h-4 w-4 text-indigo-400" />
                <h3 className="text-sm font-semibold text-white">Live ERP Web Service Payload Inspector</h3>
              </div>
              <span className="font-mono text-[10px] text-slate-400">
                {selectedSystem === 'netsuite' ? 'NetSuite SuiteTalk REST API v1' : 'SAP S/4HANA OData v2'}
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Live payload generated by the backend gateway dispatch worker:
            </p>

            {/* Code Box */}
            <div className="rounded-lg border border-slate-800 bg-slate-900/90 p-4 font-mono text-[11px] text-indigo-300 overflow-x-auto max-h-96">
              <pre>
                {latestSyncPayload
                  ? JSON.stringify(latestSyncPayload, null, 2)
                  : JSON.stringify(
                      selectedSystem === 'netsuite'
                        ? {
                            targetSystem: 'Oracle NetSuite SuiteTalk REST API',
                            entity: 'expenseReport',
                            batchId: 'SYNC-INITIAL-READY',
                            subsidiary: '1 (Acme US Holding)',
                            accountingPeriod: 'FY2026-Q3',
                            glDistribution: [
                              { account: '6100 Meals & Entertainment', debit: 276.53, credit: 0.0 },
                              { account: '2000 Accounts Payable Clearing', debit: 0.0, credit: 276.53 }
                            ],
                            authMode: 'OAuth 2.0 Token-Based Authentication (TBA)',
                            status: 'READY_TO_DISPATCH'
                          }
                        : {
                            targetSystem: 'SAP S/4HANA Finance BAPI',
                            service: 'API_FINANCIALTRANSACTION_SRV',
                            companyCode: 'DE10',
                            documentType: 'KR (Vendor Invoice)',
                            fiscalYear: '2026',
                            taxCode: 'V1 (Input Tax 19%)',
                            costCenterAssignment: 'CC-DE-10',
                            status: 'READY_TO_DISPATCH'
                          },
                      null,
                      2
                    )}
              </pre>
            </div>

            <div className="pt-2 text-[11px] text-slate-500 font-mono flex items-center justify-between">
              <span>Endpoint: {selectedSystem === 'netsuite' ? 'https://1234567.suitetalk.api.netsuite.com/services/rest/record/v1' : 'https://sap.s4hana.enterprise.corp:8443/sap/opu/odata/sap'}</span>
              <span className="text-emerald-400">TLS 1.3 Strict</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
