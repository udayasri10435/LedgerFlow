export type UserRole = 'employee' | 'manager' | 'controller' | 'auditor';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  title: string;
  avatarInitials: string;
  approvalLimitUSD: number;
}

export interface Tenant {
  id: string;
  name: string;
  code: string;
  country: string;
  currency: 'USD' | 'EUR' | 'GBP';
  erpType: 'netsuite' | 'sap' | 'quickbooks';
  cardProgram: 'stripe' | 'plaid';
  employeeCount: number;
  fiscalYear: string;
  departments: string[];
  costCenters: { code: string; name: string; department: string }[];
  subsidiaryId: string;
}

export interface ReceiptLineItem {
  id: string;
  name: string;
  qty: number;
  unitPrice: number;
  total: number;
  category: string;
  glAccount?: string;
}

export interface PolicyViolation {
  ruleId: string;
  ruleName: string;
  severity: 'WARNING' | 'VIOLATION' | 'INFO';
  message: string;
  actionRequired: string;
}

export interface Receipt {
  id: string;
  merchant: string;
  address?: string;
  date: string;
  time?: string;
  currency: string;
  subtotal: number;
  tax: number;
  tip?: number;
  total: number;
  paymentMethod: string;
  category: string;
  glAccountCode: string;
  lineItems: ReceiptLineItem[];
  policyViolations: PolicyViolation[];
  confidenceScore: number;
  rawImageUrl?: string;
  verified: boolean;
  sha256Hash: string;
}

export interface PolicyRule {
  id: string;
  code: string;
  name: string;
  description: string;
  category: 'MEALS' | 'TRAVEL' | 'HARDWARE' | 'SOFTWARE' | 'ENTERTAINMENT' | 'AUDIT';
  limitAmount?: number;
  severity: 'WARNING' | 'VIOLATION' | 'INFO';
  requiresApprovalRole: UserRole;
  active: boolean;
  ruleType: 'PER_DIEM' | 'FLIGHT_CLASS' | 'RECEIPT_THRESHOLD' | 'ALCOHOL' | 'WEEKEND' | 'DUPLICATE_HASH' | 'CAPEX';
}

export type WorkflowStatus = 'RUNNING' | 'COMPLETED' | 'FAILED' | 'WAITING_APPROVAL' | 'COMPENSATED';
export type StepStatus = 'COMPLETED' | 'ACTIVE' | 'PENDING' | 'REJECTED' | 'BYPASSED';

export interface WorkflowStep {
  id: string;
  stepNumber: number;
  title: string;
  roleRequired: UserRole;
  status: StepStatus;
  assignedToName: string;
  completedAt?: string;
  note?: string;
  actionType?: 'POLICY_CHECK' | 'MANAGER_SIGN' | 'DIRECTOR_SIGN' | 'CONTROLLER_AUDIT' | 'ERP_DISPATCH' | 'PAYOUT';
}

export interface WorkflowHistoryEvent {
  eventId: number;
  eventType: string;
  timestamp: string;
  details: string;
  status: 'SUCCESS' | 'WARNING' | 'ERROR';
}

export interface TemporalWorkflow {
  workflowId: string;
  runId: string;
  taskQueue: string;
  workflowType: string;
  status: WorkflowStatus;
  currentStepIndex: number;
  steps: WorkflowStep[];
  historyEvents: WorkflowHistoryEvent[];
  startedAt: string;
  timeoutSeconds: number;
  retryCount: number;
  canCompensate: boolean;
}

export interface ErpSyncInfo {
  system: 'NetSuite' | 'SAP S/4HANA' | 'QuickBooks Enterprise';
  status: 'PENDING' | 'SYNCED' | 'FAILED';
  syncBatchId: string;
  internalId?: string | number;
  sapDocNumber?: string;
  syncedAt?: string;
  glDebits?: { account: string; amount: number }[];
  glCredits?: { account: string; amount: number }[];
}

export interface Expense {
  id: string;
  expenseNumber: string;
  tenantId: string;
  submitterId: string;
  submitterName: string;
  submitterRole: string;
  department: string;
  costCenter: string;
  merchant: string;
  date: string;
  amount: number;
  currency: 'USD' | 'EUR' | 'GBP';
  category: string;
  glAccount: string;
  status: 'DRAFT' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'ERP_SYNCED' | 'REIMBURSED';
  policyStatus: 'COMPLIANT' | 'FLAGGED' | 'VIOLATION';
  policyFlags: string[];
  notes?: string;
  receipt?: Receipt;
  workflow: TemporalWorkflow;
  erpSyncInfo?: ErpSyncInfo;
  paymentSource: 'corporate_card' | 'out_of_pocket';
  cardLast4?: string;
}

export interface CorporateCard {
  id: string;
  tenantId: string;
  cardholderName: string;
  cardholderEmail: string;
  last4: string;
  brand: 'Visa' | 'Mastercard' | 'Amex';
  expMonth: number;
  expYear: number;
  status: 'ACTIVE' | 'FROZEN' | 'CANCELLED';
  spendLimitMonthly: number;
  spentThisMonth: number;
  virtual: boolean;
  department: string;
  autoFreezeOnPolicyBreach: boolean;
}

export interface PlaidTransaction {
  id: string;
  tenantId: string;
  date: string;
  merchant: string;
  amount: number;
  currency: string;
  accountName: string;
  status: 'MATCHED' | 'UNMATCHED' | 'FLAGGED';
  matchedExpenseNumber?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  tenantId: string;
  actorName: string;
  actorRole: string;
  eventType: string;
  resourceId: string;
  details: string;
  soc2Control: 'CC6.1' | 'CC6.8' | 'CC7.2' | 'CC8.1';
  prevHash: string;
  currentHash: string;
}
