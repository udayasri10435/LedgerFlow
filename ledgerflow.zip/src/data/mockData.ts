import { Tenant, User, PolicyRule, Expense, CorporateCard, PlaidTransaction, AuditEvent } from '../types';

export const MOCK_TENANTS: Tenant[] = [
  {
    id: "tenant_acme_us",
    name: "Acme Corporation US",
    code: "ACME-US",
    country: "United States",
    currency: "USD",
    erpType: "netsuite",
    cardProgram: "stripe",
    employeeCount: 185,
    fiscalYear: "2026-FY",
    departments: ["Engineering", "Sales & Field", "Marketing", "R&D", "Finance & Legal", "Executive"],
    costCenters: [
      { code: "CC-101", name: "Core Engineering R&D", department: "Engineering" },
      { code: "CC-204", name: "Enterprise Enterprise Sales", department: "Sales & Field" },
      { code: "CC-310", name: "Demand Generation", department: "Marketing" },
      { code: "CC-450", name: "Corporate Overhead", department: "Finance & Legal" },
      { code: "CC-500", name: "Executive Strategy", department: "Executive" }
    ],
    subsidiaryId: "SUB-01"
  },
  {
    id: "tenant_apex_de",
    name: "Apex Global Logistics GmbH",
    code: "APEX-DE",
    country: "Germany",
    currency: "EUR",
    erpType: "sap",
    cardProgram: "plaid",
    employeeCount: 420,
    fiscalYear: "2026-FY",
    departments: ["Fleet Operations", "Supply Chain", "IT & Platform", "Finance EU", "Human Resources"],
    costCenters: [
      { code: "CC-DE-10", name: "Logistics Hub Frankfurt", department: "Fleet Operations" },
      { code: "CC-DE-20", name: "Supply Chain Systems", department: "Supply Chain" },
      { code: "CC-DE-30", name: "European Tech Center", department: "IT & Platform" },
      { code: "CC-DE-40", name: "General Administration DE", department: "Finance EU" }
    ],
    subsidiaryId: "SUB-DE10"
  },
  {
    id: "tenant_pulse_med",
    name: "Pulse BioMed Labs",
    code: "PULSE-MED",
    country: "United States",
    currency: "USD",
    erpType: "netsuite",
    cardProgram: "stripe",
    employeeCount: 95,
    fiscalYear: "2026-FY",
    departments: ["Clinical Trials", "Bioinformatics", "Regulatory Affairs", "Operations"],
    costCenters: [
      { code: "CC-MED-01", name: "Phase II Clinical Trials", department: "Clinical Trials" },
      { code: "CC-MED-02", name: "Genomics Sequencing", department: "Bioinformatics" },
      { code: "CC-MED-03", name: "FDA Compliance & Filing", department: "Regulatory Affairs" }
    ],
    subsidiaryId: "SUB-04"
  }
];

export const MOCK_USERS: User[] = [
  {
    id: "usr_alex",
    name: "Alex Chen",
    email: "alex.chen@acme.corp",
    role: "employee",
    department: "Engineering",
    title: "Senior Staff Engineer",
    avatarInitials: "AC",
    approvalLimitUSD: 0
  },
  {
    id: "usr_sarah",
    name: "Sarah Jenkins",
    email: "sarah.jenkins@acme.corp",
    role: "manager",
    department: "Engineering",
    title: "Director of Engineering",
    avatarInitials: "SJ",
    approvalLimitUSD: 5000
  },
  {
    id: "usr_marcus",
    name: "Marcus Vance",
    email: "marcus.vance@acme.corp",
    role: "controller",
    department: "Finance & Legal",
    title: "VP of Finance & Corporate Controller",
    avatarInitials: "MV",
    approvalLimitUSD: 50000
  },
  {
    id: "usr_elena",
    name: "Elena Rostova",
    email: "e.rostova@auditing-partners.com",
    role: "auditor",
    department: "Finance & Legal",
    title: "Lead SOC 2 Type II Compliance Auditor",
    avatarInitials: "ER",
    approvalLimitUSD: 0
  }
];

export const MOCK_POLICIES: PolicyRule[] = [
  {
    id: "POL-001",
    code: "MEAL_MAX_85",
    name: "Per-Meal Dining Threshold ($85 USD)",
    description: "Meals exceeding $85 USD per person trigger a policy flag and require an attached attendee list for business verification.",
    category: "MEALS",
    limitAmount: 85,
    severity: "WARNING",
    requiresApprovalRole: "manager",
    active: true,
    ruleType: "PER_DIEM"
  },
  {
    id: "POL-002",
    code: "RECEIPT_REQ_25",
    name: "Mandatory Receipt Proof (>= $25 USD)",
    description: "IRS and SOC 2 require an itemized receipt image with verified OCR timestamp for any transaction $25 and above.",
    category: "AUDIT",
    limitAmount: 25,
    severity: "VIOLATION",
    requiresApprovalRole: "controller",
    active: true,
    ruleType: "RECEIPT_THRESHOLD"
  },
  {
    id: "POL-003",
    code: "FLIGHT_CLASS_POLICY",
    name: "Commercial Flight Class Guardrail",
    description: "Domestic and international flights under 6 hours must be booked in Economy/Coach. Business Class requires VP sign-off.",
    category: "TRAVEL",
    severity: "WARNING",
    requiresApprovalRole: "controller",
    active: true,
    ruleType: "FLIGHT_CLASS"
  },
  {
    id: "POL-004",
    code: "ALCOHOL_SEPARATION",
    name: "Alcohol Line Item Segregation",
    description: "Alcoholic beverages must be split to GL 6200 (Client Entertainment) and cannot be billed against standard meals per diem.",
    category: "ENTERTAINMENT",
    severity: "WARNING",
    requiresApprovalRole: "manager",
    active: true,
    ruleType: "ALCOHOL"
  },
  {
    id: "POL-005",
    code: "WEEKEND_JUSTIFICATION",
    name: "Weekend Expense Audit Flag",
    description: "Transactions occurring on Saturday or Sunday trigger automated review to verify customer-facing engagement.",
    category: "AUDIT",
    severity: "INFO",
    requiresApprovalRole: "manager",
    active: true,
    ruleType: "WEEKEND"
  },
  {
    id: "POL-006",
    code: "DUPLICATE_HASH_GUARD",
    name: "Cryptographic Duplicate Detection",
    description: "Detects identical SHA-256 receipt signatures or matching (Merchant + Date + Amount) across all tenants and users.",
    category: "AUDIT",
    severity: "VIOLATION",
    requiresApprovalRole: "controller",
    active: true,
    ruleType: "DUPLICATE_HASH"
  },
  {
    id: "POL-007",
    code: "CAPEX_THRESHOLD_2500",
    name: "CapEx & IT Equipment Threshold ($2,500)",
    description: "Any equipment or subscription exceeding $2,500 must receive Finance Controller & Asset Tagging review before ERP sync.",
    category: "HARDWARE",
    limitAmount: 2500,
    severity: "WARNING",
    requiresApprovalRole: "controller",
    active: true,
    ruleType: "CAPEX"
  }
];

export const MOCK_EXPENSES: Expense[] = [
  {
    id: "exp_101",
    expenseNumber: "EXP-2026-8812",
    tenantId: "tenant_acme_us",
    submitterId: "usr_alex",
    submitterName: "Alex Chen",
    submitterRole: "Senior Staff Engineer",
    department: "Engineering",
    costCenter: "CC-101",
    merchant: "Delta Air Lines",
    date: "2026-09-21",
    amount: 530.78,
    currency: "USD",
    category: "Airfare & Travel",
    glAccount: "6250 - Travel: Airfare",
    status: "ERP_SYNCED",
    policyStatus: "COMPLIANT",
    policyFlags: [],
    notes: "Q3 System Architecture Offsite in New York JFK.",
    receipt: {
      id: "rcpt_8812",
      merchant: "Delta Air Lines",
      address: "Hartsfield-Jackson Atlanta Intl Airport",
      date: "2026-09-21",
      time: "09:15",
      currency: "USD",
      subtotal: 489.20,
      tax: 41.58,
      total: 530.78,
      paymentMethod: "Amex Corporate ending in 1004",
      category: "Airfare & Travel",
      glAccountCode: "6250-TRAVEL-AIR",
      lineItems: [
        { id: "li_1", name: "Flight DL1842: SFO -> JFK (Main Cabin)", qty: 1, unitPrice: 489.20, total: 489.20, category: "Airfare" }
      ],
      policyViolations: [],
      confidenceScore: 0.99,
      verified: true,
      sha256Hash: "d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592"
    },
    workflow: {
      workflowId: "wf_exp_8812",
      runId: "run_8812_01",
      taskQueue: "finance-approvals-queue",
      workflowType: "StandardExpenseWorkflow",
      status: "COMPLETED",
      currentStepIndex: 4,
      timeoutSeconds: 86400,
      retryCount: 0,
      canCompensate: false,
      startedAt: "2026-09-21T10:00:00Z",
      steps: [
        { id: "s1", stepNumber: 1, title: "Automated Policy OCR Validation", roleRequired: "employee", status: "COMPLETED", assignedToName: "Temporal Rule Engine", completedAt: "2026-09-21T10:00:05Z", note: "All OCR line items passed strict policy checks." },
        { id: "s2", stepNumber: 2, title: "Direct Manager Approval", roleRequired: "manager", status: "COMPLETED", assignedToName: "Sarah Jenkins", completedAt: "2026-09-21T14:20:00Z", note: "Approved for Q3 NY architectural summit." },
        { id: "s3", stepNumber: 3, title: "Finance Controller Review", roleRequired: "controller", status: "COMPLETED", assignedToName: "Marcus Vance", completedAt: "2026-09-22T09:10:00Z", note: "GL coding verified against CC-101." },
        { id: "s4", stepNumber: 4, title: "NetSuite ERP Journal Post", roleRequired: "controller", status: "COMPLETED", assignedToName: "NetSuite Gateway Worker", completedAt: "2026-09-22T09:12:00Z", note: "SuiteTalk Internal ID #492019 created." }
      ],
      historyEvents: [
        { eventId: 1, eventType: "WorkflowExecutionStarted", timestamp: "2026-09-21T10:00:00Z", details: "Temporal workflow instance initialized with payload EXP-2026-8812.", status: "SUCCESS" },
        { eventId: 2, eventType: "ActivityTaskScheduled [OCRValidation]", timestamp: "2026-09-21T10:00:01Z", details: "Invoked Multimodal OCR extractor.", status: "SUCCESS" },
        { eventId: 3, eventType: "ActivityTaskCompleted [OCRValidation]", timestamp: "2026-09-21T10:00:05Z", details: "Confidence 0.99. Receipt verified.", status: "SUCCESS" },
        { eventId: 4, eventType: "ApprovalSignalReceived [ManagerApprove]", timestamp: "2026-09-21T14:20:00Z", details: "Sarah Jenkins approved step 2.", status: "SUCCESS" },
        { eventId: 5, eventType: "ApprovalSignalReceived [ControllerApprove]", timestamp: "2026-09-22T09:10:00Z", details: "Marcus Vance signed off step 3.", status: "SUCCESS" },
        { eventId: 6, eventType: "WorkflowExecutionCompleted", timestamp: "2026-09-22T09:12:00Z", details: "Dispatched to NetSuite. Status: 201 Created.", status: "SUCCESS" }
      ]
    },
    erpSyncInfo: {
      system: "NetSuite",
      status: "SYNCED",
      syncBatchId: "SYNC-M39K1L",
      internalId: 492019,
      syncedAt: "2026-09-22T09:12:00Z",
      glDebits: [{ account: "6250 Travel: Airfare", amount: 530.78 }],
      glCredits: [{ account: "2000 Corporate Amex Clearing", amount: 530.78 }]
    },
    paymentSource: "corporate_card",
    cardLast4: "1004"
  },
  {
    id: "exp_102",
    expenseNumber: "EXP-2026-8815",
    tenantId: "tenant_acme_us",
    submitterId: "usr_alex",
    submitterName: "Alex Chen",
    submitterRole: "Senior Staff Engineer",
    department: "Engineering",
    costCenter: "CC-101",
    merchant: "Ruth's Prime Steakhouse",
    date: "2026-09-24",
    amount: 276.53,
    currency: "USD",
    category: "Meals & Entertainment",
    glAccount: "6100 - Meals & Entertainment",
    status: "PENDING_APPROVAL",
    policyStatus: "FLAGGED",
    policyFlags: [
      "Per-meal threshold exceeded ($85 limit)",
      "Alcohol line item detected ($62.00)"
    ],
    notes: "Engineering roadmap dinner with candidate and key client partner.",
    receipt: {
      id: "rcpt_8815",
      merchant: "Ruth's Prime Steakhouse",
      address: "400 California St, San Francisco, CA 94104",
      date: "2026-09-24",
      time: "20:42",
      currency: "USD",
      subtotal: 218.00,
      tax: 18.53,
      tip: 40.00,
      total: 276.53,
      paymentMethod: "Visa ending in 4829",
      category: "Meals & Entertainment",
      glAccountCode: "6100-MEALS",
      lineItems: [
        { id: "li_201", name: "Bone-in Ribeye 16oz", qty: 2, unitPrice: 68.00, total: 136.00, category: "Food" },
        { id: "li_202", name: "Cabernet Sauvignon (Bottle)", qty: 1, unitPrice: 62.00, total: 62.00, category: "Alcohol", glAccount: "6200" },
        { id: "li_203", name: "Creamed Spinach", qty: 1, unitPrice: 20.00, total: 20.00, category: "Food" }
      ],
      policyViolations: [
        {
          ruleId: "POL-001",
          ruleName: "Per-Meal Dining Limit ($85/person)",
          severity: "WARNING",
          message: "Total of $276.53 exceeds individual per-meal guideline. Requires attendee list verification.",
          actionRequired: "Attach attendee list in notes"
        },
        {
          ruleId: "POL-004",
          ruleName: "Alcohol Policy Itemization",
          severity: "WARNING",
          message: "Alcohol line item ($62.00) detected. Must map to Entertainment GL 6200 and requires Director approval.",
          actionRequired: "Route to Department Director"
        }
      ],
      confidenceScore: 0.98,
      verified: true,
      sha256Hash: "b890f614a82dc8526848ef98b1e42b260907a12b0bbefec5418b76dd3d41f021"
    },
    workflow: {
      workflowId: "wf_exp_8815",
      runId: "run_8815_02",
      taskQueue: "finance-approvals-queue",
      workflowType: "StandardExpenseWorkflow",
      status: "WAITING_APPROVAL",
      currentStepIndex: 1,
      timeoutSeconds: 86400,
      retryCount: 0,
      canCompensate: true,
      startedAt: "2026-09-24T22:15:00Z",
      steps: [
        { id: "s1", stepNumber: 1, title: "Automated Policy OCR Validation", roleRequired: "employee", status: "COMPLETED", assignedToName: "Temporal Rule Engine", completedAt: "2026-09-24T22:15:04Z", note: "Flagged 2 policy warnings: Exceeded per-meal and Alcohol line item." },
        { id: "s2", stepNumber: 2, title: "Direct Manager Approval", roleRequired: "manager", status: "ACTIVE", assignedToName: "Sarah Jenkins", note: "Pending approval. Reviewing client attendee list and alcohol itemization." },
        { id: "s3", stepNumber: 3, title: "Finance Controller Review", roleRequired: "controller", status: "PENDING", assignedToName: "Marcus Vance" },
        { id: "s4", stepNumber: 4, title: "NetSuite ERP Journal Post", roleRequired: "controller", status: "PENDING", assignedToName: "NetSuite Gateway Worker" }
      ],
      historyEvents: [
        { eventId: 1, eventType: "WorkflowExecutionStarted", timestamp: "2026-09-24T22:15:00Z", details: "Temporal workflow instance initialized with payload EXP-2026-8815.", status: "SUCCESS" },
        { eventId: 2, eventType: "ActivityTaskCompleted [OCRValidation]", timestamp: "2026-09-24T22:15:04Z", details: "Policy check completed with 2 WARNING items.", status: "WARNING" },
        { eventId: 3, eventType: "TimerStarted [48h_Manager_Escalation]", timestamp: "2026-09-24T22:15:05Z", details: "Temporal durable timer set for SLA escalation.", status: "SUCCESS" }
      ]
    },
    paymentSource: "out_of_pocket"
  },
  {
    id: "exp_103",
    expenseNumber: "EXP-2026-8820",
    tenantId: "tenant_acme_us",
    submitterId: "usr_alex",
    submitterName: "Alex Chen",
    submitterRole: "Senior Staff Engineer",
    department: "Engineering",
    costCenter: "CC-101",
    merchant: "Amazon Web Services Inc.",
    date: "2026-09-01",
    amount: 1240.50,
    currency: "USD",
    category: "Cloud Infrastructure",
    glAccount: "6300 - Cloud Hosting: AWS",
    status: "ERP_SYNCED",
    policyStatus: "COMPLIANT",
    policyFlags: [],
    notes: "Monthly staging & AI benchmark server clusters.",
    receipt: {
      id: "rcpt_8820",
      merchant: "Amazon Web Services Inc.",
      address: "410 Terry Ave N, Seattle, WA 98109",
      date: "2026-09-01",
      time: "00:00",
      currency: "USD",
      subtotal: 1240.50,
      tax: 0.00,
      total: 1240.50,
      paymentMethod: "Stripe Virtual Card ending in 9102",
      category: "Cloud Infrastructure",
      glAccountCode: "6300-HOSTING-AWS",
      lineItems: [
        { id: "li_301", name: "Amazon EC2 Production Clusters", qty: 1, unitPrice: 840.00, total: 840.00, category: "Compute" },
        { id: "li_302", name: "Amazon Aurora PostgreSQL Serverless", qty: 1, unitPrice: 280.50, total: 280.50, category: "Database" },
        { id: "li_303", name: "Amazon S3 Standard Storage", qty: 1, unitPrice: 120.00, total: 120.00, category: "Storage" }
      ],
      policyViolations: [],
      confidenceScore: 0.99,
      verified: true,
      sha256Hash: "6f52e259e2112d7b43f9a74482bc85d11593c66f56b5797f3b55c65f9a7493a8"
    },
    workflow: {
      workflowId: "wf_exp_8820",
      runId: "run_8820_01",
      taskQueue: "finance-approvals-queue",
      workflowType: "StandardExpenseWorkflow",
      status: "COMPLETED",
      currentStepIndex: 4,
      timeoutSeconds: 86400,
      retryCount: 0,
      canCompensate: false,
      startedAt: "2026-09-01T08:00:00Z",
      steps: [
        { id: "s1", stepNumber: 1, title: "Automated Policy OCR Validation", roleRequired: "employee", status: "COMPLETED", assignedToName: "Temporal Rule Engine", completedAt: "2026-09-01T08:00:03Z", note: "Compliant" },
        { id: "s2", stepNumber: 2, title: "Direct Manager Approval", roleRequired: "manager", status: "COMPLETED", assignedToName: "Sarah Jenkins", completedAt: "2026-09-01T11:00:00Z", note: "Approved standard cloud infrastructure." },
        { id: "s3", stepNumber: 3, title: "Finance Controller Review", roleRequired: "controller", status: "COMPLETED", assignedToName: "Marcus Vance", completedAt: "2026-09-01T14:30:00Z", note: "Reconciled with Stripe Virtual Card #9102." },
        { id: "s4", stepNumber: 4, title: "NetSuite ERP Journal Post", roleRequired: "controller", status: "COMPLETED", assignedToName: "NetSuite Gateway Worker", completedAt: "2026-09-01T14:35:00Z", note: "NetSuite ID #489912 posted." }
      ],
      historyEvents: [
        { eventId: 1, eventType: "WorkflowExecutionStarted", timestamp: "2026-09-01T08:00:00Z", details: "Workflow started.", status: "SUCCESS" },
        { eventId: 2, eventType: "WorkflowExecutionCompleted", timestamp: "2026-09-01T14:35:00Z", details: "ERP Posted successfully.", status: "SUCCESS" }
      ]
    },
    erpSyncInfo: {
      system: "NetSuite",
      status: "SYNCED",
      syncBatchId: "SYNC-AWS901",
      internalId: 489912,
      syncedAt: "2026-09-01T14:35:00Z",
      glDebits: [{ account: "6300 Cloud Hosting: AWS", amount: 1240.50 }],
      glCredits: [{ account: "2000 Stripe Corporate Payable", amount: 1240.50 }]
    },
    paymentSource: "corporate_card",
    cardLast4: "9102"
  },
  {
    id: "exp_104",
    expenseNumber: "EXP-2026-8824",
    tenantId: "tenant_acme_us",
    submitterId: "usr_alex",
    submitterName: "Alex Chen",
    submitterRole: "Senior Staff Engineer",
    department: "Engineering",
    costCenter: "CC-101",
    merchant: "Apple Inc.",
    date: "2026-09-18",
    amount: 326.66,
    currency: "USD",
    category: "Hardware & Peripherals",
    glAccount: "6500 - Hardware & IT Equipment",
    status: "APPROVED",
    policyStatus: "FLAGGED",
    policyFlags: ["Hardware Stipend Limit ($300/yr) - Exceeded by $26.66"],
    notes: "CalDigit Thunderbolt 4 dock and cables for multi-monitor workstation.",
    receipt: {
      id: "rcpt_8824",
      merchant: "Apple Inc.",
      address: "1 Infinite Loop, Cupertino, CA 95014",
      date: "2026-09-18",
      time: "14:10",
      currency: "USD",
      subtotal: 299.00,
      tax: 27.66,
      total: 326.66,
      paymentMethod: "Visa ending in 4829",
      category: "Hardware & Peripherals",
      glAccountCode: "6500-EQUIPMENT-IT",
      lineItems: [
        { id: "li_401", name: "CalDigit TS4 Thunderbolt 4 Dock", qty: 1, unitPrice: 299.00, total: 299.00, category: "Hardware" }
      ],
      policyViolations: [
        {
          ruleId: "POL-007",
          ruleName: "Hardware Stipend Limit ($300/yr)",
          severity: "INFO",
          message: "Peripherals above $300 require IT Asset Management registration.",
          actionRequired: "Submit serial number for IT registry"
        }
      ],
      confidenceScore: 0.97,
      verified: true,
      sha256Hash: "8899aabbccddeeff00112233445566778899aabbccddeeff0011223344556677"
    },
    workflow: {
      workflowId: "wf_exp_8824",
      runId: "run_8824_01",
      taskQueue: "finance-approvals-queue",
      workflowType: "StandardExpenseWorkflow",
      status: "RUNNING",
      currentStepIndex: 2,
      timeoutSeconds: 86400,
      retryCount: 0,
      canCompensate: true,
      startedAt: "2026-09-18T15:00:00Z",
      steps: [
        { id: "s1", stepNumber: 1, title: "Automated Policy OCR Validation", roleRequired: "employee", status: "COMPLETED", assignedToName: "Temporal Rule Engine", completedAt: "2026-09-18T15:00:04Z", note: "Flagged $26.66 over stipend." },
        { id: "s2", stepNumber: 2, title: "Direct Manager Approval", roleRequired: "manager", status: "COMPLETED", assignedToName: "Sarah Jenkins", completedAt: "2026-09-19T10:00:00Z", note: "Approved exception due to multi-screen engineering needs." },
        { id: "s3", stepNumber: 3, title: "Finance Controller Review", roleRequired: "controller", status: "ACTIVE", assignedToName: "Marcus Vance", note: "Ready for Controller sign-off and ERP dispatch." },
        { id: "s4", stepNumber: 4, title: "NetSuite ERP Journal Post", roleRequired: "controller", status: "PENDING", assignedToName: "NetSuite Gateway Worker" }
      ],
      historyEvents: [
        { eventId: 1, eventType: "WorkflowExecutionStarted", timestamp: "2026-09-18T15:00:00Z", details: "Workflow started.", status: "SUCCESS" },
        { eventId: 2, eventType: "ApprovalSignalReceived", timestamp: "2026-09-19T10:00:00Z", details: "Sarah Jenkins approved exception.", status: "SUCCESS" }
      ]
    },
    paymentSource: "out_of_pocket"
  },
  {
    id: "exp_201",
    expenseNumber: "EXP-2026-9041",
    tenantId: "tenant_apex_de",
    submitterId: "usr_alex",
    submitterName: "Hans Gruber",
    submitterRole: "Operations Lead",
    department: "Fleet Operations",
    costCenter: "CC-DE-10",
    merchant: "Deutsche Bahn AG",
    date: "2026-09-22",
    amount: 142.80,
    currency: "EUR",
    category: "Ground Transportation",
    glAccount: "6260 - Ground Transit / Rail",
    status: "ERP_SYNCED",
    policyStatus: "COMPLIANT",
    policyFlags: [],
    notes: "ICE High-Speed Rail Ticket Frankfurt to Munich Hub inspection.",
    receipt: {
      id: "rcpt_9041",
      merchant: "Deutsche Bahn AG",
      address: "Frankfurt (Main) Hbf",
      date: "2026-09-22",
      time: "07:30",
      currency: "EUR",
      subtotal: 120.00,
      tax: 22.80,
      total: 142.80,
      paymentMethod: "Plaid Corporate Checking ACH",
      category: "Ground Transportation",
      glAccountCode: "6260-TRAVEL-RAIL",
      lineItems: [
        { id: "li_501", name: "ICE 1st Class Flexpreis Business", qty: 1, unitPrice: 120.00, total: 120.00, category: "Transit" }
      ],
      policyViolations: [],
      confidenceScore: 0.99,
      verified: true,
      sha256Hash: "11223344556677889900aabbccddeeff11223344556677889900aabbccddeeff"
    },
    workflow: {
      workflowId: "wf_exp_9041",
      runId: "run_9041_01",
      taskQueue: "sap-finance-queue",
      workflowType: "GermanTaxCompliantWorkflow",
      status: "COMPLETED",
      currentStepIndex: 3,
      timeoutSeconds: 86400,
      retryCount: 0,
      canCompensate: false,
      startedAt: "2026-09-22T08:00:00Z",
      steps: [
        { id: "s1", stepNumber: 1, title: "GoBD & Tax Compliance Check", roleRequired: "employee", status: "COMPLETED", assignedToName: "Temporal Tax Worker", completedAt: "2026-09-22T08:00:03Z", note: "German 19% MwSt. input tax verified." },
        { id: "s2", stepNumber: 2, title: "Operations Director Sign-off", roleRequired: "manager", status: "COMPLETED", assignedToName: "Klaus Wagner", completedAt: "2026-09-22T11:00:00Z", note: "Hub inspection approved." },
        { id: "s3", stepNumber: 3, title: "SAP S/4HANA Idoc Dispatch", roleRequired: "controller", status: "COMPLETED", assignedToName: "SAP BAPI Gateway", completedAt: "2026-09-22T11:05:00Z", note: "Doc #0100481029 generated in Company Code DE10." }
      ],
      historyEvents: [
        { eventId: 1, eventType: "WorkflowExecutionStarted", timestamp: "2026-09-22T08:00:00Z", details: "SAP Workflow started.", status: "SUCCESS" },
        { eventId: 2, eventType: "WorkflowExecutionCompleted", timestamp: "2026-09-22T11:05:00Z", details: "Posted to SAP S/4HANA successfully.", status: "SUCCESS" }
      ]
    },
    erpSyncInfo: {
      system: "SAP S/4HANA",
      status: "SYNCED",
      syncBatchId: "SYNC-SAP-892",
      sapDocNumber: "0100481029",
      syncedAt: "2026-09-22T11:05:00Z"
    },
    paymentSource: "corporate_card"
  }
];

export const MOCK_CARDS: CorporateCard[] = [
  {
    id: "crd_001",
    tenantId: "tenant_acme_us",
    cardholderName: "Alex Chen",
    cardholderEmail: "alex.chen@acme.corp",
    last4: "4829",
    brand: "Visa",
    expMonth: 12,
    expYear: 2028,
    status: "ACTIVE",
    spendLimitMonthly: 5000,
    spentThisMonth: 1843.85,
    virtual: false,
    department: "Engineering",
    autoFreezeOnPolicyBreach: true
  },
  {
    id: "crd_002",
    tenantId: "tenant_acme_us",
    cardholderName: "Sarah Jenkins",
    cardholderEmail: "sarah.jenkins@acme.corp",
    last4: "1004",
    brand: "Amex",
    expMonth: 8,
    expYear: 2029,
    status: "ACTIVE",
    spendLimitMonthly: 15000,
    spentThisMonth: 4210.00,
    virtual: false,
    department: "Engineering",
    autoFreezeOnPolicyBreach: false
  },
  {
    id: "crd_003",
    tenantId: "tenant_acme_us",
    cardholderName: "Cloud DevOps Virtual Card",
    cardholderEmail: "devops-billing@acme.corp",
    last4: "9102",
    brand: "Visa",
    expMonth: 4,
    expYear: 2027,
    status: "ACTIVE",
    spendLimitMonthly: 25000,
    spentThisMonth: 1240.50,
    virtual: true,
    department: "Engineering",
    autoFreezeOnPolicyBreach: true
  },
  {
    id: "crd_004",
    tenantId: "tenant_apex_de",
    cardholderName: "Hans Gruber",
    cardholderEmail: "h.gruber@apex-logistics.de",
    last4: "3381",
    brand: "Mastercard",
    expMonth: 11,
    expYear: 2028,
    status: "ACTIVE",
    spendLimitMonthly: 4000,
    spentThisMonth: 890.20,
    virtual: false,
    department: "Fleet Operations",
    autoFreezeOnPolicyBreach: true
  }
];

export const MOCK_PLAID_TRANSACTIONS: PlaidTransaction[] = [
  {
    id: "tx_plaid_01",
    tenantId: "tenant_acme_us",
    date: "2026-09-24",
    merchant: "Ruth's Prime Steakhouse",
    amount: 276.53,
    currency: "USD",
    accountName: "JPMorgan Operating Account (..9902)",
    status: "MATCHED",
    matchedExpenseNumber: "EXP-2026-8815"
  },
  {
    id: "tx_plaid_02",
    tenantId: "tenant_acme_us",
    date: "2026-09-21",
    merchant: "Delta Air Lines",
    amount: 530.78,
    currency: "USD",
    accountName: "Amex Corporate Billing (..1004)",
    status: "MATCHED",
    matchedExpenseNumber: "EXP-2026-8812"
  },
  {
    id: "tx_plaid_03",
    tenantId: "tenant_acme_us",
    date: "2026-09-27",
    merchant: "Lyft *Ride SFO",
    amount: 34.20,
    currency: "USD",
    accountName: "JPMorgan Operating Account (..9902)",
    status: "UNMATCHED"
  },
  {
    id: "tx_plaid_04",
    tenantId: "tenant_apex_de",
    date: "2026-09-22",
    merchant: "Deutsche Bahn AG",
    amount: 142.80,
    currency: "EUR",
    accountName: "Deutsche Bank Corporate Euro (..4108)",
    status: "MATCHED",
    matchedExpenseNumber: "EXP-2026-9041"
  }
];

export const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  {
    id: "aud_001",
    timestamp: "2026-09-28T14:10:00Z",
    tenantId: "tenant_acme_us",
    actorName: "System Engine",
    actorRole: "System",
    eventType: "POLICY_INITIALIZED",
    resourceId: "POL-001",
    details: "Initialized SOC 2 CC6.8 Policy configuration: Per-meal limit set to $85.00 USD.",
    soc2Control: "CC6.8",
    prevHash: "0000000000000000000000000000000000000000000000000000000000000000",
    currentHash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  {
    id: "aud_002",
    timestamp: "2026-09-28T16:22:15Z",
    tenantId: "tenant_acme_us",
    actorName: "Alex Chen",
    actorRole: "Employee",
    eventType: "EXPENSE_SUBMITTED",
    resourceId: "EXP-2026-8812",
    details: "Submitted travel expense for Delta Air Lines flight ($530.78 USD) with verified OCR receipt.",
    soc2Control: "CC7.2",
    prevHash: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    currentHash: "6c28f11b22894b9015949a2dae7ea50259e83a6697fa22ad4f7572cb9a2bc3a4"
  },
  {
    id: "aud_003",
    timestamp: "2026-09-28T17:05:40Z",
    tenantId: "tenant_acme_us",
    actorName: "Sarah Jenkins",
    actorRole: "Manager",
    eventType: "APPROVAL_GRANTED",
    resourceId: "EXP-2026-8812",
    details: "Approved expense EXP-2026-8812. Enforced segregation of duties: approver distinct from submitter.",
    soc2Control: "CC8.1",
    prevHash: "6c28f11b22894b9015949a2dae7ea50259e83a6697fa22ad4f7572cb9a2bc3a4",
    currentHash: "9a0a55e2e85a6e8779b5c2a11b6473ec0b029279cbe87fa9f3424f9c063cf461"
  },
  {
    id: "aud_004",
    timestamp: "2026-09-28T18:00:10Z",
    tenantId: "tenant_acme_us",
    actorName: "Marcus Vance",
    actorRole: "Controller",
    eventType: "ERP_DISPATCHED",
    resourceId: "EXP-2026-8812",
    details: "Dispatched batch to NetSuite SuiteTalk REST API. Internal ID: 492019 generated.",
    soc2Control: "CC7.2",
    prevHash: "9a0a55e2e85a6e8779b5c2a11b6473ec0b029279cbe87fa9f3424f9c063cf461",
    currentHash: "3f82a101b449cd2094892c90a149021481029381029481902840192840192840"
  }
];
